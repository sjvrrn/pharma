-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 23, 2019 at 07:58 AM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 5.6.36

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pharma`
--

-- --------------------------------------------------------

--
-- Table structure for table `content`
--

CREATE TABLE `content` (
  `id` int(5) NOT NULL,
  `type` varchar(40) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `content`
--

INSERT INTO `content` (`id`, `type`, `createdAt`) VALUES
(1, 'slide', '2019-08-18 16:42:47'),
(2, 'text', '2019-08-18 16:42:47'),
(3, 'video', '2019-08-18 16:42:47'),
(4, 'image', '2019-08-18 16:42:47'),
(5, 'keywords', '2019-08-18 16:45:31'),
(6, 'widgets', '2019-08-20 06:51:05');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `id` int(5) NOT NULL,
  `name` varchar(75) NOT NULL,
  `description` text NOT NULL,
  `file_path` varchar(75) NOT NULL,
  `created_At` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`id`, `name`, `description`, `file_path`, `created_At`) VALUES
(1, 'Quality Control', 'Curabitur aliquet lacinia libero one sitamet lucturaesent odio loremips veliconsectetu.', 'slider-18.jpg', '2019-08-19 11:04:21'),
(2, 'Stability', 'Aliquam at vestibulum ipsumrasid cursus ligula aliquam nibama nulla acsem lobortis suscipe.', 'course-pic.jpg', '2019-08-18 20:19:36'),
(3, 'AR&D', 'Curabitur aliquet lacinia libero one sitamet lucturaesent odio loremips veliconsectetu.', 'course-pic1.jpg', '2019-08-18 20:20:07'),
(4, 'Regulatory Affairs ', 'Nullam efficitur semper dapibusn euismod sodales lacuut vulputate est blandit nonuis.', 'course-pic2.jpg', '2019-08-18 20:20:42'),
(5, 'Validation', ' Aliquam at vestibulum ipsumrasid cursus ligula aliquam nibama nulla acsem lobortis suscipe.', 'course-pic3.jpg', '2019-08-18 20:21:37'),
(6, 'Guidlines ', 'Aliquam at vestibulum ipsumrasid cursus ligula aliquam nibama nulla acsem lobortis suscipe.', 'course-pic4.jpg', '2019-08-18 20:22:07'),
(7, 'Calibration ', 'Aliquam at vestibulum ipsumrasid cursus ligula aliquam nibama nulla acsem lobortis suscipe.', 'course-pic5.jpg', '2019-08-18 20:22:34'),
(8, 'Production', ' Aliquam at vestibulum ipsumrasid cursus ligula aliquam nibama nulla acsem lobortis suscipe.', 'course-pic6.jpg', '2019-08-18 20:52:55');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `id` int(5) NOT NULL,
  `name` varchar(30) NOT NULL,
  `createdAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`id`, `name`, `createdAt`) VALUES
(1, 'Home', '2019-08-18 15:57:24'),
(2, 'About', '2019-08-18 15:57:24'),
(3, 'Courses', '2019-08-18 15:57:24'),
(4, 'Career', '2019-08-18 15:57:24'),
(5, 'Project', '2019-08-18 15:57:24'),
(6, 'Services', '2019-08-18 15:57:24'),
(7, 'Contact', '2019-08-18 15:57:24');

-- --------------------------------------------------------

--
-- Table structure for table `page`
--

CREATE TABLE `page` (
  `id` int(5) NOT NULL,
  `menu_id` int(5) NOT NULL,
  `type_id` int(5) NOT NULL,
  `content` text NOT NULL,
  `created_At` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `page`
--

INSERT INTO `page` (`id`, `menu_id`, `type_id`, `content`, `created_At`) VALUES
(1, 1, 1, 'slider-317.jpg', '2019-08-19 10:31:21'),
(2, 1, 1, 'slider-3.jpg', '2019-08-18 19:11:16'),
(3, 1, 2, 'Costarica is a branded Pharmaceutical company that has entered the market in 2018. Our Company brings a fresh and inventive approach to meet the unmet needs.Costarica is a fast growing organization established by a team of professionals with over decades of experience in the pharmaceutical industry with specific reference to service oriented .', '2019-08-19 10:06:29'),
(4, 2, 1, 'slider-31.jpg', '2019-08-18 19:25:13'),
(6, 2, 2, 'Costarica is a branded Pharmaceutical company that has entered the market in 2018. Our Company brings a fresh and inventive approach to meet the unmet needs.\\\\r\\\\n\\\\r\\\\nCostarica is a fast growing organization established by a team of professionals with over decades of experience in the pharmaceutical industry with specific reference to service oriented .', '2019-08-18 19:52:58'),
(7, 3, 2, 'Costarica is a dynamic , rapidly evolving organization that is working to meet the needs of the healthcare professionals and their patients.\\\\r\\\\n\\\\r\\\\nTo ensure we can continue to deliver on our commitments to the customers who rely on us, we are focused on improving the way we do business; on operating with transparency in everything we do; and on listening to the views of all of the people involved in health care decisions. our goal is to ensure that people everywhere have access to innovative treatments and quality health care.', '2019-08-18 20:51:19'),
(8, 4, 1, 'slider-19.jpg', '2019-08-21 05:11:01'),
(9, 4, 1, 'slider-32.jpg', '2019-08-18 20:58:19'),
(10, 5, 1, 'slider-13.jpg', '2019-08-18 21:05:18'),
(11, 5, 1, 'testi-pic-1.jpg', '2019-08-18 21:05:43'),
(12, 5, 2, 'Project At Costarica, we believe our employees are the reason for all our successes. Our future depends on our global community of employees whose varied perspectives, experiences and skills fuel the creativity for pharmaceutical innovation.', '2019-08-18 21:10:10'),
(13, 6, 1, 'slider-14.jpg', '2019-08-18 21:11:50');

-- --------------------------------------------------------

--
-- Table structure for table `submenu`
--

CREATE TABLE `submenu` (
  `id` int(5) NOT NULL,
  `name` char(25) NOT NULL,
  `menu_id` int(5) NOT NULL,
  `created_At` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `submenu`
--

INSERT INTO `submenu` (`id`, `name`, `menu_id`, `created_At`) VALUES
(1, 'Regulartory', 6, '2019-08-19 14:10:05'),
(2, 'Dossiers_development', 6, '2019-08-20 03:02:59'),
(3, 'Regulatory_affairs', 6, '2019-08-20 03:04:17'),
(5, 'Course', 3, '2019-08-19 14:08:18'),
(6, 'Project', 5, '2019-08-19 14:09:26'),
(9, 'Researchwork', 5, '2019-08-20 06:53:19');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(5) NOT NULL,
  `email` char(25) NOT NULL,
  `password` varchar(100) NOT NULL,
  `file_path` varchar(100) NOT NULL,
  `created_At` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
-- Error reading data for table pharma.user: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `pharma`.`user`' at line 1

-- --------------------------------------------------------

--
-- Table structure for table `widgets`
--

CREATE TABLE `widgets` (
  `id` int(5) NOT NULL,
  `menuId` tinyint(2) NOT NULL,
  `file_path` varchar(50) NOT NULL,
  `content` text NOT NULL,
  `alignment` tinytext NOT NULL,
  `createAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `widgets`
--

INSERT INTO `widgets` (`id`, `menuId`, `file_path`, `content`, `alignment`, `createAt`) VALUES
(4, 0, 'slider-111.jpg', '<h1>Scope of Work</h1>\r\n\r\n<ul>\r\n	<li>Drafting and Editing all sections of DMF</li>\r\n	<li>&nbsp;</li>\r\n	<li>Documentation of the following</li>\r\n	<li>&nbsp;</li>\r\n	<li>Drug Substance Characterization&nbsp;</li>\r\n	<li>&nbsp;</li>\r\n	<li>Drug Substance Characterization</li>\r\n	<li>&nbsp;</li>\r\n	<li>Stability Study</li>\r\n	<li>&nbsp;</li>\r\n	<li>Product Development Reports (PDR)</li>\r\n	<li>&nbsp;</li>\r\n	<li>Process Validation Protocol and Reports</li>\r\n	<li>&nbsp;</li>\r\n	<li>Method Validation Protocol and Reports</li>\r\n	<li>&nbsp;</li>\r\n	<li>Technology Transfer</li>\r\n	<li>&nbsp;</li>\r\n	<li>Chemistry, Manufacture and Control (CMC) information (Narayana1)</li>\r\n</ul>\r\n', '2', '2019-08-21 11:38:16'),
(5, 9, 'about-pic1.jpg', '<h1>Expertise Offered In</h1><ul>	<li>Abbreviated New Drug Application (ANDA) - US</li>	<li>&nbsp;</li>	<li>European Union Registration - EU</li>	<li>&nbsp;</li>	<li>Medicines &amp; Healthcare Products Regulatory Agency (MHRA) - UK&nbsp;</li>	<li>&nbsp;</li>	<li>Therapeutic Goods Administration (TGA) - Australia</li>	<li>&nbsp;</li>	<li>Medicines Control Council (MCC) - South Africa</li>	<li>&nbsp;</li>	<li>Commonwealth of Independent States (CIS) Registration</li>	<li>&nbsp;</li>	<li>Registration in all other Regions across the globe</li></ul>', '2', '2019-08-21 07:20:16'),
(7, 9, 'slider-2.jpg', '<h1>Scope of Work</h1><ul>	<li>Drafting and Editing all sections of DMF</li>	<li>Documentation of the following</li>	<li>Drug Substance Characterization</li>	<li>Drug Substance Characterization</li>	<li>Stability Study</li>	<li>Product Development Reports (PDR)</li>	<li>Process Validation Protocol and Reports</li>	<li>Method Validation Protocol and Reports</li>	<li>Technology Transfer</li>	<li>Chemistry, Manufacture and Control (CMC) information</li></ul>', '1', '2019-08-21 07:47:33');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `content`
--
ALTER TABLE `content`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `page`
--
ALTER TABLE `page`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `submenu`
--
ALTER TABLE `submenu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `widgets`
--
ALTER TABLE `widgets`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `content`
--
ALTER TABLE `content`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `page`
--
ALTER TABLE `page`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `submenu`
--
ALTER TABLE `submenu`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `widgets`
--
ALTER TABLE `widgets`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
