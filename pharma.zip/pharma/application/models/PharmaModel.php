<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class PharmaModel extends CI_Model {
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct(){
		parent::__construct();		
		$this->load->database();
	}
	//login
	public function login($data){
		$this->db->select('email,password,id,file_path');
		$this->db->from('user');
		$this->db->where('email',$data['email']);
		$this->db->where('password',$data['password']);
		$query = $this->db->get();
		$result = $query->result_array();
		if(count($result)>0)
		        return $result; 
		    else
		    	return array();

	}
	//menu
	public function menu(){
		$data = $this->db->query('select id,name from menu union select id,name from submenu')->result_array();
		if(count($data)>0)
			return  $data;
		else
			return array();
	}
	public function submenu(){
		$data = $this->db->query('select id,name from submenu')->result_array();
		if(count($data)>0)
			return  $data;
		else
			return array();
	}
    //content
    public function content(){
		$data = $this->db->get('content')->result_array();
		if(count($data)>0)
			return  $data;
		else
			return array();
	}
    //addContent
    public function addContent($data){
		$data = $this->db->insert('page',$data);
		if(count($this->db->affected_rows())>0)
			return  1;
		else
			return 0;
	}
	//addCourse
	public function addCourse($data){
		$data = $this->db->insert('course',$data);
		if(count($this->db->affected_rows())>0)
			return  1;
		else
			return 0;
	}
	//slider
	 public function slider($id){
		$data = $this->db->get_where('page',array('menu_id'=>(int)$id,'type_id'=>1))->result_array();
		if(count($data)>0)
			return  $data;
		else
			return array();
	}
	//content
    public function text($id){
		$data = $this->db->get_where('page',array('menu_id'=>(int)$id,'type_id'=>2))->result_array();
		if(count($data)>0)
			return  $data;
		else
			return array();
	}
	////content
    public function widgets($id){
		$data = $this->db->get_where('widgets',array('menuId'=>(int)$id))->result_array();
		if(count($data)>0)
			return  $data;
		else
			return array();
	}
	//coursesList
	 public function coursesList(){
		$data = $this->db->get('course')->result_array();
		if(count($data)>0)
			return  $data;
		else
			return array();
	}
	//listcontent
	public function listcontent(){
	 	$query = "select m.name,p.id,p.type_id,p.content from page p inner join menu m on m.id = p.menu_id";
	 	$query = $this->db->query($query);
		$data = $query->result_array();
		if(count($data)>0)
			return  $data;
		else
			return array();
	}
	//listcourses
	public function listcourses(){
	 	$data = $this->db->get('course')->result_array();
		if(count($data)>0)
			return  $data;
		else
			return array();
	}
	//removecontent
	public function removecontent($id){
	 	$this->db->where('id',$id);
	 	$this->db->delete('page');
		if(count($this->db->affected_rows())>0)
			return  1;
		else
			return 0;
	}
	//getContent
	public function getContent($id){
	 	$data = $this->db->get_where('page',array('id'=>$id))->result_array();
		if(count($this->db->affected_rows())>0)
			return  $data;
		else
			return array();
    }
    //updateContent
    public function updateContent($data){
    	$id = $data['id'];
    	$content = $data['content'];
	 	$data = $this->db->where('id',$id);
	 	$this->db->update('page',array('content'=>$content));
		if(count($this->db->affected_rows())>0)
			return  1;
		else
			return 0;
    }
    //courseDetails
    public function courseDetails($id){  
	 	$data = $this->db->get_where('course',array('id'=>$id))->result_array();
		if(count($this->db->affected_rows())>0)
			return  $data;
		else
			return array();
    }
    //courseDetails
    public function updateCourse($id,$data){ 
	 	$this->db->where('id',$id);
	 	$this->db->update('course',$data);
		if(count($this->db->affected_rows())>0)
			return  1;
		else
			return 0;
    }
    //addPage
     public function addPage($data){ 
		    $this->db->insert('submenu',$data);
				if(count($this->db->affected_rows())>0)
					return  1;
				else
					return 0;
   	 	    }      
   	//editpage
   	public function updatepage($id,$name){ 
	 	$this->db->where('id',$id);
	 	$this->db->update('submenu',array('name'=>$name));
		if(count($this->db->affected_rows())>0)
			return  1;
		else
			return 0;
    }      
    //pager
    public function pager($id){
    	$this->db->where('id',base64_decode($id)); 
    	$response = $this->db->delete('submenu');
    	if(count($this->db->affected_rows())>0)
			return  1;
		else
			return 0;
    }
    //addWidget
    public function addWidget($data){ 
	    	$response = $this->db->insert('widgets',$data);
	    	if(count($this->db->affected_rows())>0)
				return  1;
			else
				return 0;
    }
    //getwidgets
    public function getwidgets(){ 
	    	$response = $this->db->get('widgets')->result_array();
	    	if(count($response)>0)
				return  $response;
			else
				return array();
    }
    //widgetdata
    public function widgetdata($id){
    	$response = $this->db->get_where('widgets',array('id'=>$id))->result();
    	if(count($response)>0)
    		return $response[0];
    	else 
    		return array();
    }
    //updateWidget
    public function updateWidget($id,$widget){ 
    	$this->db->where('id',$id);
    	$this->db->update('widgets',$widget);
    	if(count($this->db->affected_rows())>0)
			return  1;
		else
			return 0;
    }
    //removewidget
    public function removewidget($id){
    	$this->db->where('id',$id);
    	$response = $this->db->delete('widgets');
    	if(count($this->db->affected_rows())>0)
			return  1;
		else
			return 0;
    }
}
