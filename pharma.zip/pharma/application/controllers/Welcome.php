<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct(){
		parent::__construct();
		$this->load->helper('url');
		$this->load->library('session');
		$this->load->library('form_validation');
		$sections = array(
        'config'  => TRUE,
        'queries' => TRUE
		);

		//$this->output->set_profiler_sections($sections);
		//$this->output->enable_profiler(TRUE);		
	}

	public function pageContent($id){
		$data['sliders'] = $this->PharmaModel->slider($id); 
		$data['text'] = $this->PharmaModel->text($id);
		return $data;
    }

	public function index()
	{   
		$data = $this->pageContent(1);
        $this->load->view('pharma/index',$data);
	}
	//about
	public function about(){
		
		$data = $this->pageContent(2);
		$this->load->view('pharma/about',$data);
	}
	//contact
	public function contact(){
		$this->load->view('pharma/contact');
	}
	//course
	public function course(){
        $data = $this->pageContent(3);
		$data['courses'] = $this->PharmaModel->coursesList(); 
		$this->load->view('pharma/course',$data);
	}
	//courseSingle
	public function courseSingle(){
		$this->load->view('pharma/courses-single');
	}
	//careers
	public function careers(){
		 $data = $this->pageContent(4);
		$this->load->view('pharma/careers',$data);
	}
	//project
	public function project(){
		$data = $this->pageContent(5);
		$this->load->view('pharma/project',$data);
	}
	//services
	public function services(){
		$data = $this->pageContent(6);
		$this->load->view('pharma/services',$data);
	}
	//dossiers_development
	public function dossiers_development(){
		$this->load->view('pharma/dossiers-development');
	}
	//regulatory_affairs
	public function regulatory_affairs(){
		$this->load->view('pharma/regulatory-affairs');
	}
	//regulatory
	public function regulatory(){
		$this->load->view('pharma/regulatory');
	}
	//core_segments
	public function core_segments(){
		$this->load->view('pharma/core-segments');
	}
	//login
	public function login(){

		if($this->input->post('email')){
			$data = array('email'=>$this->db->escape_str($this->input->post('email')),'password'=>$this->db->escape_str(md5($this->input->post('password'))));
			$login = $this->PharmaModel->login($data); 
			if(count($login)>0){
				$this->session->set_userdata($login[0]); 
				 $this->session->set_flashdata('status','Login Success');
				redirect('admin');
			}else{
                 $this->session->set_flashdata('status','! Login Failed  please try again');
			}
          }  
		redirect('/');
	}
    //logout
    public function userlogout(){
    	        $this->load->library('session');
    			$this->session->unset_userdata(TRUE); 
    			$this->session->sess_destroy();
    			redirect('/');
    }


}
