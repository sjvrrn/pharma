<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct(){
		parent::__construct();
		$this->load->helper('url','form');
		$this->load->library(array('session','form_validation'));	
	}
	//index
	public function index()
	{
		$this->load->view('admin/index');
	}
	//slide
	public function addSlide(){ 
        if($this->input->post('menu')){  
        	$this->form_validation->set_rules('menu','Menu','required');
        	$this->form_validation->set_rules('type','Content Type','required');
        	if($this->input->post('content')!=="")
        	$this->form_validation->set_rules('content','Content','required|min_length[20]|max_length[700]');
        	if($this->form_validation->run() === FALSE){  
        	                   $this->session->set_flashdata('status',validation_errors());
                               redirect('admin/addSlide');
        	}
	         if($_FILES['file']['name']!==""){

	         	$config['upload_path'] = './uploads';
	         	$config['max_size'] = '10000';
	         	$config['allowed_types'] = 'jpg|png';
	         	$this->load->library('upload',$config);
	         	if(!$this->upload->do_upload('file')){
	              $errors = $this->upload->display_errors();
	              $this->session->set_flashdata('status', $errors);
	                               redirect('admin/addSlide');
	         	}else{

	         		$data = $this->upload->data();
	         		$file_path = $data['file_name'];  
	         		$content= $file_path;
	         	}	         	
	         }        	

	         if(!$content){
	         	$content = $this->db->escape_str($this->input->post('content'));
	         }
	         $data = array('menu_id'=>$this->db->escape_str($this->input->post('menu')),'type_id'=>$this->db->escape_str($this->input->post('type')),'content'=>$this->db->escape_str($content));
	         $slide = $this->PharmaModel->addContent($data);
	         if($slide)
	         	 $this->session->set_flashdata('status',"Content Added");
	         	else
	         		 $this->session->set_flashdata('status',"Content Add Failed");
                
                redirect('admin/addSlide');
        }

		$menu         = $this->PharmaModel->menu();
		$content      = $this->PharmaModel->content(); 
		$data['menu'] =  $menu ; 
		$data['content'] =  $content; 
		$this->load->view('admin/addSlide',$data);
	}
    //course
    public function course(){ 

        if($this->input->post('description')){  
        	$this->form_validation->set_rules('name','Name','required');
        	$this->form_validation->set_rules('description','Description','required');
        	if($this->form_validation->run() === FALSE){  
        	                   $this->session->set_flashdata('status',validation_errors());
                               redirect('admin/course');
        	}
	         if($_FILES['file']['name']!==""){

	         	$config['upload_path'] = './uploads';
	         	$config['max_size'] = '10000';
	         	$config['allowed_types'] = 'jpg|png';
	         	$this->load->library('upload',$config);
	         	if(!$this->upload->do_upload('file')){
	              $errors = $this->upload->display_errors();
	              $this->session->set_flashdata('status', $errors);
	                               redirect('admin/course');
	         	}else{

	         		$data = $this->upload->data();
	         		$file_path = $data['file_name'];  
	         		
	         	}	         	
	         }        	
	         $data = array('name'=>$this->db->escape_str($this->input->post('name')),'description'=>$this->db->escape_str($this->input->post('description')),'file_path'=>$this->db->escape_str($file_path));
	         $slide = $this->PharmaModel->addCourse($data);
	         if($slide)
	         	 $this->session->set_flashdata('status',"Course Added");
	         	else
	         		 $this->session->set_flashdata('status',"Course Add Failed");
                
                redirect('admin/course');
        }
		$this->load->view('admin/course');
	}
	//listcontent
	public function listcontent(){
	        $content = $this->PharmaModel->listcontent();
	        $data['content'] = $content; 
	 		$this->load->view('admin/listcontent',$data);
	}
	//contente
	public function contente(){
		    $id = (int)$this->uri->segment(2); 
	        $response = $this->PharmaModel->removecontent($id);
	        if($response)
	        	$this->session->set_flashdata('status','Deleted Successfully');
	        else
	        	$this->session->set_flashdata('status','Deleted Failed');
	        redirect('listcontent');
   }
   //listcourses
   public function listcourses(){
	        $content = $this->PharmaModel->listcourses();
	        $data['courses'] = $content; 
	 		$this->load->view('admin/listcourses',$data);
	}
	//editContent
	public function editContent(){  
	         if($this->input->post('id')){  
	        	 $id = $this->db->escape_str($this->input->post('id')); 
		         if($this->input->post('content')=="" && $_FILES['file']['name']!==""){ 
		         	$config['upload_path'] = './uploads';
		         	$config['max_size'] = '10000';
		         	$config['allowed_types'] = 'jpg|png';
		         	$this->load->library('upload',$config);
		         	if(!$this->upload->do_upload('file')){
		              $errors = $this->upload->display_errors();
		              $this->session->set_flashdata('status', $errors);
		                               redirect('pagecontent/'.base64_encode($id)); die;
			         	}else{
             				$data = $this->upload->data();
			         		$file_path = $data['file_name'];  
			         		$content= $file_path;
			         	}	         	
			         }else{
			         	$content =  $this->db->escape_str($this->input->post('content'));
			         }        	
 					$data = array('id'=>$this->db->escape_str($id),'content'=>$this->db->escape_str($content)); 
			         $content = $this->PharmaModel->updateContent($data); 
			         if($content)
			         	 $this->session->set_flashdata('status',"Content updated");
			         	else
			         		 $this->session->set_flashdata('status',"Content update Failed");
                    
                    redirect('pagecontent/'.base64_encode($id)); die;
		        } 
	            //udpate end
		    $id = base64_decode($this->uri->segment(2));  
	        $content = $this->PharmaModel->getContent($id);
	        if(count($content)>0)
	        {
	          $data['details'] = $content; 
	          	$menu         = $this->PharmaModel->menu();
				$content      = $this->PharmaModel->content(); 
				$data['menu'] =  $menu ; 
				$data['content'] =  $content; 
	 		  $this->load->view('admin/contentDetails',$data); 	
	        }else{
	        	redirect('listcontent');
	        }
	}
	//coursese
	 public function coursese(){

	 		if($this->input->post('id')){  
        	 $id = $this->db->escape_str($this->input->post('id')); 
        	 $description =  $this->db->escape_str($this->input->post('description'));
		     $name        =  $this->db->escape_str($this->input->post('title'));
        	 $data = array('name'=>$this->db->escape_str($name),'description'=>$this->db->escape_str($description)); 

	         if($_FILES['file']['name']!==""){ 

	         	$config['upload_path'] = './uploads';
	         	$config['max_size'] = '10000';
	         	$config['allowed_types'] = 'jpg|png';
	         	$this->load->library('upload',$config);
	         	if(!$this->upload->do_upload('file')){
	              $errors = $this->upload->display_errors();
	              $this->session->set_flashdata('status', $errors);
	                               redirect('coursese/'.base64_encode($id)); die;
		         	}else{

		         		$filedata = $this->upload->data();
		         		$file_path = $filedata['file_name'];  
		         		$data['file_path']= $file_path;
		         	}	         	
		         }
		         
		         $content = $this->PharmaModel->updateCourse($id,$data); 
		         if($content)
		         	 $this->session->set_flashdata('status',"Content updated");
		         	else
		         		 $this->session->set_flashdata('status',"Content update Failed");

	                redirect('coursese/'.base64_encode($id)); die;
	        } 
            //update end
	 	    $id = base64_decode($this->uri->segment(2)); 
	        $content = $this->PharmaModel->courseDetails($id);
	        $data['details'] = $content;
	 		$this->load->view('admin/courseDetails',$data);
	}
	//courser
	public function courser(){
		$id = $this->uri->segment(2);
		$response = $this->PharmaModel->courser($id);
		if($response)
		   $this->session->set_flashdata('status',"Course Removed Successfully");
		 else
		   $this->session->set_flashdata('status',"Course Remove Failed");
		redirect('listcourses');
	}
	//page
	public function page(){

	        if($this->input->post('name')){
              
	              $this->form_validation->set_rules('name','Page Name','required|min_length[5]|max_length[25]');
	              $this->form_validation->set_rules('menu','Menu','required');
	              if( $this->form_validation->run()==FALSE){
	              		$this->session->set_flashdata('status',validation_errors());
	                    redirect('page');
	              }
	              $data = array('menu_id'=>$this->db->escape_str($this->input->post('menu')),"name"=>$this->db->escape_str(ucfirst($this->input->post('name'))));
	              $response = $this->PharmaModel->addPage($data); 
	              if($response)
					   $this->session->set_flashdata('status',"Page Added Successfully");
				    else
					   $this->session->set_flashdata('status',"Page Added Failed");
					redirect('page');
			}
			$menu         = $this->PharmaModel->menu();
			$data['menu'] = $menu;
			$this->load->view('admin/page',$data);
	}
	//listpage
	public function listpage()
	{   
		$listpages = $this->PharmaModel->submenu();
	    $data['pages'] = $listpages; 
		$this->load->view('admin/listpages',$data);
	}
	//editpage
	public function editpage(){
			if($this->input->post('name')){
              $id = $this->input->post('id');
              $name = $this->input->post('name'); 
              $response = $this->PharmaModel->updatepage($id,$name);
               if($response)
	         	   echo '1';
	         	else
	         		 echo"0";
		}

	}
	//page remove
	public function pager(){
		$id = $this->uri->segment(2);
		$response = $this->PharmaModel->pager($id);
		if($response)
		   $this->session->set_flashdata('status',"Page Removed Successfully");
		 else
		   $this->session->set_flashdata('status',"Page Remove Failed");
		redirect('listpage');
	}
}
