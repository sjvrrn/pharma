<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-08-19 05:17:48 --> Severity: Parsing Error --> syntax error, unexpected '$content' (T_VARIABLE), expecting ';' or '{' E:\xamp\htdocs\pharma\application\controllers\Admin.php 119
ERROR - 2019-08-19 05:18:33 --> Severity: Parsing Error --> syntax error, unexpected '$content' (T_VARIABLE), expecting ';' or '{' E:\xamp\htdocs\pharma\application\controllers\Admin.php 119
ERROR - 2019-08-19 05:18:35 --> Severity: Parsing Error --> syntax error, unexpected '$content' (T_VARIABLE), expecting ';' or '{' E:\xamp\htdocs\pharma\application\controllers\Admin.php 119
ERROR - 2019-08-19 05:19:36 --> Severity: Parsing Error --> syntax error, unexpected '$data' (T_VARIABLE) E:\xamp\htdocs\pharma\application\models\PharmaModel.php 99
ERROR - 2019-08-19 05:21:05 --> Query error: Unknown column 'p.type' in 'field list' - Invalid query: select m.name,p.id,p.type,p.content from page p inner join menu m on m.id = p.menu_id
ERROR - 2019-08-19 05:31:27 --> Severity: Parsing Error --> syntax error, unexpected end of file E:\xamp\htdocs\pharma\application\views\admin\listcontent.php 91
ERROR - 2019-08-19 05:37:58 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listcontent.php 65
ERROR - 2019-08-19 05:37:58 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listcontent.php 65
ERROR - 2019-08-19 05:37:58 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listcontent.php 65
ERROR - 2019-08-19 05:37:58 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listcontent.php 65
ERROR - 2019-08-19 05:37:58 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listcontent.php 65
ERROR - 2019-08-19 05:37:58 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listcontent.php 65
ERROR - 2019-08-19 05:37:58 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listcontent.php 65
ERROR - 2019-08-19 05:37:58 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listcontent.php 65
ERROR - 2019-08-19 05:37:58 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listcontent.php 65
ERROR - 2019-08-19 05:37:58 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listcontent.php 65
ERROR - 2019-08-19 05:37:58 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listcontent.php 65
ERROR - 2019-08-19 05:37:58 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listcontent.php 65
ERROR - 2019-08-19 05:37:58 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listcontent.php 65
ERROR - 2019-08-19 05:37:58 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listcontent.php 65
ERROR - 2019-08-19 05:38:02 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listcontent.php 65
ERROR - 2019-08-19 05:38:02 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listcontent.php 65
ERROR - 2019-08-19 05:38:02 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listcontent.php 65
ERROR - 2019-08-19 05:38:02 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listcontent.php 65
ERROR - 2019-08-19 05:38:02 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listcontent.php 65
ERROR - 2019-08-19 05:38:02 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listcontent.php 65
ERROR - 2019-08-19 05:38:02 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listcontent.php 65
ERROR - 2019-08-19 05:38:02 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listcontent.php 65
ERROR - 2019-08-19 05:38:02 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listcontent.php 65
ERROR - 2019-08-19 05:38:02 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listcontent.php 65
ERROR - 2019-08-19 05:38:02 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listcontent.php 65
ERROR - 2019-08-19 05:38:02 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listcontent.php 65
ERROR - 2019-08-19 05:38:02 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listcontent.php 65
ERROR - 2019-08-19 05:38:02 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listcontent.php 65
ERROR - 2019-08-19 05:44:04 --> 404 Page Not Found: Listcontent/5
ERROR - 2019-08-19 05:44:21 --> 404 Page Not Found: Admin/removeContent
ERROR - 2019-08-19 05:51:13 --> Severity: Notice --> Undefined property: CI_DB_mysqli_driver::$affected_rows E:\xamp\htdocs\pharma\application\models\PharmaModel.php 109
ERROR - 2019-08-19 05:58:04 --> Query error: Table 'pharma.courses' doesn't exist - Invalid query: SELECT *
FROM `courses`
ERROR - 2019-08-19 05:58:20 --> Severity: Notice --> Undefined variable: content E:\xamp\htdocs\pharma\application\views\admin\listcontent.php 52
ERROR - 2019-08-19 05:59:43 --> Severity: Notice --> Undefined variable: content E:\xamp\htdocs\pharma\application\views\admin\listcontent.php 52
ERROR - 2019-08-19 06:00:36 --> Severity: Notice --> Undefined variable: content E:\xamp\htdocs\pharma\application\views\admin\listcontent.php 52
ERROR - 2019-08-19 06:02:10 --> Severity: Notice --> Undefined variable: content E:\xamp\htdocs\pharma\application\views\admin\listcontent.php 52
ERROR - 2019-08-19 06:02:13 --> Severity: Notice --> Undefined variable: content E:\xamp\htdocs\pharma\application\views\admin\listcontent.php 52
ERROR - 2019-08-19 06:12:43 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 06:12:43 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 06:12:44 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 06:12:44 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 06:12:44 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 06:12:44 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 06:12:44 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 06:12:44 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 06:12:44 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 06:12:44 --> 404 Page Not Found: Img/courses
ERROR - 2019-08-19 06:18:26 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 06:18:26 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 06:18:26 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 06:18:26 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 06:18:26 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 06:18:26 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 06:18:26 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 06:18:26 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 06:18:26 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 06:18:26 --> 404 Page Not Found: Img/courses
ERROR - 2019-08-19 06:30:45 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 06:30:45 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 06:30:45 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 06:30:45 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 06:30:46 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 06:30:46 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 06:30:46 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 06:30:46 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 06:30:46 --> 404 Page Not Found: Img/courses
ERROR - 2019-08-19 06:30:46 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 06:31:58 --> 404 Page Not Found: Widgetshtml/index
ERROR - 2019-08-19 07:13:10 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:13:10 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:13:10 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:13:10 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 07:13:10 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:13:10 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 07:13:10 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:13:10 --> 404 Page Not Found: Img/courses
ERROR - 2019-08-19 07:13:10 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:13:10 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 07:13:28 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 07:13:28 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 07:13:28 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:13:28 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:13:28 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:13:28 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:13:28 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:13:28 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:13:28 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 07:13:28 --> 404 Page Not Found: Img/courses
ERROR - 2019-08-19 07:14:44 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 07:14:44 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 07:14:44 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:14:44 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:14:44 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:14:44 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:14:44 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:14:44 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:14:44 --> 404 Page Not Found: Img/courses
ERROR - 2019-08-19 07:14:44 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 07:15:09 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 07:15:09 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 07:15:09 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:15:09 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:15:09 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:15:09 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:15:09 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:15:09 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:15:09 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 07:15:09 --> 404 Page Not Found: Img/courses
ERROR - 2019-08-19 07:15:27 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 07:15:27 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 07:15:28 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:15:28 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:15:28 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:15:28 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:15:28 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:15:28 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 07:15:28 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:15:28 --> 404 Page Not Found: Img/courses
ERROR - 2019-08-19 07:15:46 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 07:15:46 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 07:15:47 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:15:47 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:15:47 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:15:47 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:15:47 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:15:47 --> 404 Page Not Found: Img/courses
ERROR - 2019-08-19 07:15:47 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 07:15:47 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:34:25 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 07:34:25 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:34:25 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:34:25 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:34:25 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 07:34:25 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:34:26 --> 404 Page Not Found: Img/courses
ERROR - 2019-08-19 07:34:26 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 07:34:26 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:34:26 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:42:56 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 07:42:56 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 07:42:56 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:42:56 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:42:56 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:42:56 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:42:56 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:42:56 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 07:42:56 --> 404 Page Not Found: Img/courses
ERROR - 2019-08-19 07:42:56 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:48:48 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 07:48:48 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 07:48:48 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:48:48 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:48:48 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:48:48 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:48:48 --> 404 Page Not Found: Img/courses
ERROR - 2019-08-19 07:48:48 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:48:48 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:48:48 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 07:49:22 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 07:49:22 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 07:49:22 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:49:22 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:49:23 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:49:23 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:49:23 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:49:23 --> 404 Page Not Found: Img/courses
ERROR - 2019-08-19 07:49:23 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 07:49:23 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 07:53:45 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 07:53:52 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 07:54:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 08:04:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 08:04:53 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 08:05:22 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 08:05:22 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 08:05:22 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:05:22 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:05:22 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:05:22 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:05:22 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:05:22 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:05:23 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 08:05:23 --> 404 Page Not Found: Img/courses
ERROR - 2019-08-19 08:14:03 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 08:14:03 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 08:14:03 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:14:03 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:14:03 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:14:04 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:14:04 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:14:04 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:14:04 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 08:14:04 --> 404 Page Not Found: Img/courses
ERROR - 2019-08-19 08:14:53 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 08:14:53 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 08:14:54 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:14:54 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:14:54 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:14:54 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:14:54 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:14:54 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:14:54 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 08:14:54 --> 404 Page Not Found: Img/courses
ERROR - 2019-08-19 08:14:58 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 08:14:58 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:14:58 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:14:58 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 08:14:58 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:14:58 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:14:58 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 08:14:58 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:14:59 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:14:59 --> 404 Page Not Found: Img/courses
ERROR - 2019-08-19 08:20:07 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 08:20:08 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 08:20:08 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:20:08 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:20:08 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:20:08 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:20:08 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:20:08 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 08:20:08 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:20:08 --> 404 Page Not Found: Img/courses
ERROR - 2019-08-19 08:20:30 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 08:20:31 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 08:20:31 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:20:31 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:20:31 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:20:31 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:20:31 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:20:31 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:20:31 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 08:20:31 --> 404 Page Not Found: Img/courses
ERROR - 2019-08-19 08:23:29 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 08:23:29 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 08:23:29 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:23:29 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:23:29 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:23:30 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:23:30 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:23:30 --> 404 Page Not Found: Img/courses
ERROR - 2019-08-19 08:23:30 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:23:30 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 08:43:13 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:43:13 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:43:13 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:43:13 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:43:13 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 08:43:13 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 08:43:13 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:43:13 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:43:13 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 08:43:13 --> 404 Page Not Found: Img/courses
ERROR - 2019-08-19 08:44:26 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:44:26 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 08:44:26 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:44:26 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 08:44:26 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:44:26 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:44:26 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 08:44:26 --> 404 Page Not Found: Img/courses
ERROR - 2019-08-19 08:44:26 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:44:26 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:45:48 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 08:45:48 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 08:45:48 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:45:48 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:45:48 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:45:48 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:45:48 --> 404 Page Not Found: Img/courses
ERROR - 2019-08-19 08:45:48 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:45:48 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:45:48 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 08:46:14 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 08:46:14 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 08:46:14 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:46:14 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:46:14 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:46:14 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:46:14 --> 404 Page Not Found: Img/courses
ERROR - 2019-08-19 08:46:14 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:46:14 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 08:46:14 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:46:28 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-19 08:46:41 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 08:46:41 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:46:41 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 08:46:41 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:46:41 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:46:41 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:46:41 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 08:46:41 --> 404 Page Not Found: Img/courses
ERROR - 2019-08-19 08:46:41 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:46:41 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:49:28 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 08:49:28 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 08:49:28 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:49:28 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:49:29 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:49:29 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:49:29 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:49:29 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 08:49:29 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:49:29 --> 404 Page Not Found: Img/courses
ERROR - 2019-08-19 08:49:47 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 08:49:47 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 08:49:47 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:49:47 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:49:47 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 08:49:47 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:49:47 --> 404 Page Not Found: Img/courses
ERROR - 2019-08-19 08:49:47 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:49:47 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:49:47 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:52:24 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 08:52:24 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 08:52:24 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:52:24 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:52:24 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:52:24 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:52:24 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:52:24 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 08:52:24 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:52:24 --> 404 Page Not Found: Img/courses
ERROR - 2019-08-19 08:54:27 --> Severity: Parsing Error --> syntax error, unexpected '" alt="' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ';' E:\xamp\htdocs\pharma\application\views\admin\sidebar.php 6
ERROR - 2019-08-19 08:54:40 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 08:54:40 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 08:54:40 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:54:40 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:54:40 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:54:40 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:54:41 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:54:41 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 08:54:41 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 08:54:41 --> 404 Page Not Found: Img/courses
ERROR - 2019-08-19 08:54:41 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 08:55:13 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 08:55:52 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 08:58:09 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 08:59:10 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 08:59:59 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 09:02:12 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 09:03:13 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 09:04:50 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 09:05:08 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 09:05:42 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 09:06:24 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 09:06:56 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 09:07:59 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 09:08:17 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 09:09:10 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 09:09:21 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 09:10:05 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 09:10:09 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 09:10:22 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 09:10:35 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 09:11:05 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 09:12:23 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 09:12:28 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 09:13:22 --> 404 Page Not Found: Pagecontent/1
ERROR - 2019-08-19 09:23:59 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 09:24:03 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 09:24:07 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 09:25:40 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 09:25:43 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 09:36:37 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 09:38:34 --> Severity: Notice --> Undefined index: name E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php 41
ERROR - 2019-08-19 09:38:35 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 09:39:07 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 09:39:41 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 09:43:26 --> Severity: Notice --> Undefined variable: menu E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php 43
ERROR - 2019-08-19 09:43:26 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php 43
ERROR - 2019-08-19 09:43:26 --> Severity: Notice --> Undefined variable: content E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php 55
ERROR - 2019-08-19 09:43:26 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php 55
ERROR - 2019-08-19 09:43:26 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 10:08:09 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 10:12:42 --> Severity: Notice --> Undefined variable: menu E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php 44
ERROR - 2019-08-19 10:12:42 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php 44
ERROR - 2019-08-19 10:12:42 --> Severity: Notice --> Undefined variable: m E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php 57
ERROR - 2019-08-19 10:12:42 --> Severity: Warning --> Illegal string offset 'id' E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php 57
ERROR - 2019-08-19 10:12:42 --> Severity: Warning --> Illegal string offset 'type' E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php 57
ERROR - 2019-08-19 10:12:42 --> Severity: Notice --> Undefined variable: m E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php 57
ERROR - 2019-08-19 10:12:42 --> Severity: Warning --> Illegal string offset 'id' E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php 57
ERROR - 2019-08-19 10:12:42 --> Severity: Warning --> Illegal string offset 'type' E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php 57
ERROR - 2019-08-19 10:12:42 --> Severity: Notice --> Undefined variable: m E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php 57
ERROR - 2019-08-19 10:12:42 --> Severity: Warning --> Illegal string offset 'id' E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php 57
ERROR - 2019-08-19 10:12:42 --> Severity: Warning --> Illegal string offset 'type' E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php 57
ERROR - 2019-08-19 10:12:42 --> Severity: Notice --> Undefined variable: m E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php 57
ERROR - 2019-08-19 10:12:42 --> Severity: Warning --> Illegal string offset 'id' E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php 57
ERROR - 2019-08-19 10:12:42 --> Severity: Warning --> Illegal string offset 'type' E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php 57
ERROR - 2019-08-19 10:12:42 --> Severity: Notice --> Undefined variable: m E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php 57
ERROR - 2019-08-19 10:12:42 --> Severity: Warning --> Illegal string offset 'id' E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php 57
ERROR - 2019-08-19 10:12:42 --> Severity: Warning --> Illegal string offset 'type' E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php 57
ERROR - 2019-08-19 10:12:42 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 10:13:18 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 10:14:31 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 10:14:59 --> Severity: Notice --> Undefined variable: menu E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php 43
ERROR - 2019-08-19 10:14:59 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php 43
ERROR - 2019-08-19 10:14:59 --> Severity: Notice --> Undefined variable: m E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php 56
ERROR - 2019-08-19 10:14:59 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php 56
ERROR - 2019-08-19 10:14:59 --> Severity: Notice --> Undefined index: type E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php 56
ERROR - 2019-08-19 10:14:59 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php 62
ERROR - 2019-08-19 10:14:59 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php 62
ERROR - 2019-08-19 10:14:59 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 10:16:23 --> Severity: Notice --> Undefined variable: menu E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php 44
ERROR - 2019-08-19 10:16:23 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php 44
ERROR - 2019-08-19 10:16:23 --> Severity: Notice --> Undefined variable: content E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php 56
ERROR - 2019-08-19 10:16:23 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php 56
ERROR - 2019-08-19 10:16:24 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 10:17:00 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 10:18:11 --> Severity: Notice --> Undefined variable: menu E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php 44
ERROR - 2019-08-19 10:18:11 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php 44
ERROR - 2019-08-19 10:18:11 --> Severity: Notice --> Undefined variable: content E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php 56
ERROR - 2019-08-19 10:18:11 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php 56
ERROR - 2019-08-19 10:18:11 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 10:18:34 --> Severity: Notice --> Undefined variable: menu E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php 35
ERROR - 2019-08-19 10:18:35 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 10:19:36 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 10:19:50 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 10:20:12 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 10:20:26 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 10:21:04 --> Severity: Error --> Cannot use object of type stdClass as array E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php 35
ERROR - 2019-08-19 10:21:05 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 10:21:20 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 10:21:40 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 10:22:06 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 10:31:55 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 10:33:19 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 10:33:42 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 10:35:25 --> Severity: Notice --> Undefined property: stdClass::$file_path E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php 78
ERROR - 2019-08-19 10:35:25 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 10:37:18 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 10:38:38 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 10:38:58 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 10:42:07 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 10:44:16 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 10:44:19 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 10:45:17 --> Severity: Warning --> Missing argument 1 for CI_URI::segment(), called in E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php on line 52 and defined E:\xamp\htdocs\pharma\system\core\URI.php 344
ERROR - 2019-08-19 10:45:17 --> Severity: Notice --> Undefined variable: n E:\xamp\htdocs\pharma\system\core\URI.php 346
ERROR - 2019-08-19 10:45:17 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 10:48:35 --> Severity: Warning --> Missing argument 1 for CI_URI::segment(), called in E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php on line 52 and defined E:\xamp\htdocs\pharma\system\core\URI.php 344
ERROR - 2019-08-19 10:48:35 --> Severity: Notice --> Undefined variable: n E:\xamp\htdocs\pharma\system\core\URI.php 346
ERROR - 2019-08-19 10:48:35 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 10:48:49 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:15:54 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:16:54 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:17:10 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:18:10 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:18:17 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:18:45 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:18:51 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:18:59 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:23:15 --> Severity: Compile Error --> Cannot redeclare PharmaModel::getContent() E:\xamp\htdocs\pharma\application\models\PharmaModel.php 130
ERROR - 2019-08-19 11:23:24 --> Severity: Compile Error --> Cannot redeclare PharmaModel::getContent() E:\xamp\htdocs\pharma\application\models\PharmaModel.php 130
ERROR - 2019-08-19 11:24:39 --> 404 Page Not Found: Admin/courseDetails
ERROR - 2019-08-19 11:25:03 --> 404 Page Not Found: Admin/courseDetails
ERROR - 2019-08-19 11:25:08 --> 404 Page Not Found: CourseDetails/index
ERROR - 2019-08-19 11:26:12 --> 404 Page Not Found: Admin/courseDetails
ERROR - 2019-08-19 11:26:22 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:27:48 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:27:56 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:28:04 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:28:07 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:28:14 --> 404 Page Not Found: Admin/courseDetails
ERROR - 2019-08-19 11:28:24 --> 404 Page Not Found: Admin/courseDetails
ERROR - 2019-08-19 11:28:52 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:29:25 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:29:33 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:30:50 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:30:57 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:31:00 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:31:06 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:31:11 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:31:17 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:31:23 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:31:30 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:32:15 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:32:22 --> Severity: Notice --> Undefined index: file E:\xamp\htdocs\pharma\application\controllers\Admin.php 145
ERROR - 2019-08-19 11:32:23 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:32:33 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:32:39 --> Severity: Notice --> Undefined index: file E:\xamp\htdocs\pharma\application\controllers\Admin.php 145
ERROR - 2019-08-19 11:32:39 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:34:06 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:34:09 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:34:29 --> Severity: Notice --> Undefined index: file E:\xamp\htdocs\pharma\application\controllers\Admin.php 145
ERROR - 2019-08-19 11:34:29 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:34:37 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:34:41 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:34:52 --> Severity: Notice --> Undefined index: file E:\xamp\htdocs\pharma\application\controllers\Admin.php 145
ERROR - 2019-08-19 11:34:52 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:35:46 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:35:51 --> Severity: Notice --> Undefined index: file E:\xamp\htdocs\pharma\application\controllers\Admin.php 145
ERROR - 2019-08-19 11:35:51 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:36:16 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:36:17 --> Severity: Notice --> Undefined index: file E:\xamp\htdocs\pharma\application\controllers\Admin.php 145
ERROR - 2019-08-19 11:37:18 --> Severity: Notice --> Undefined index: file E:\xamp\htdocs\pharma\application\controllers\Admin.php 145
ERROR - 2019-08-19 11:38:11 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:38:17 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:38:26 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:38:29 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:38:36 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:38:39 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:38:48 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:38:50 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:38:59 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:39:02 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:39:54 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:40:02 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:46:21 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:47:15 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:47:31 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:47:37 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:47:47 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:52:04 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:53:04 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:53:10 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:54:00 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 11:58:02 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:00:11 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:00:22 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:00:26 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:00:51 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:02:05 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:02:10 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:02:17 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:02:23 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:02:44 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:03:04 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:03:14 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:03:19 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:03:43 --> Severity: Notice --> Undefined variable: id E:\xamp\htdocs\pharma\application\controllers\Admin.php 154
ERROR - 2019-08-19 12:03:43 --> 404 Page Not Found: Pagecontent/index
ERROR - 2019-08-19 12:04:14 --> 404 Page Not Found: Pagecontent/index
ERROR - 2019-08-19 12:04:24 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:04:30 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:04:38 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:05:19 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:05:24 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:05:47 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:05:58 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:06:12 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:06:19 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:06:29 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:06:36 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:07:43 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:14:33 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:14:38 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:15:18 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:15:22 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:15:30 --> 404 Page Not Found: Coursese/coursese
ERROR - 2019-08-19 12:16:15 --> 404 Page Not Found: Coursese/coursese
ERROR - 2019-08-19 12:26:48 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:26:52 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:26:54 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:27:04 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:27:06 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:29:18 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:29:51 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:31:14 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:31:22 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:32:56 --> Severity: Compile Error --> Cannot redeclare PharmaModel::getContent() E:\xamp\htdocs\pharma\application\models\PharmaModel.php 141
ERROR - 2019-08-19 12:33:22 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:34:17 --> Severity: Notice --> Undefined variable: details E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php 36
ERROR - 2019-08-19 12:34:17 --> Severity: Notice --> Undefined variable: menu E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php 47
ERROR - 2019-08-19 12:34:17 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php 47
ERROR - 2019-08-19 12:34:17 --> Severity: Notice --> Undefined variable: content E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php 60
ERROR - 2019-08-19 12:34:17 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php 60
ERROR - 2019-08-19 12:34:17 --> Severity: Notice --> Undefined property: stdClass::$type_id E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php 67
ERROR - 2019-08-19 12:34:17 --> Severity: Notice --> Undefined property: stdClass::$type_id E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php 67
ERROR - 2019-08-19 12:34:17 --> Severity: Notice --> Undefined property: stdClass::$content E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php 80
ERROR - 2019-08-19 12:34:17 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:35:26 --> Severity: Notice --> Undefined property: stdClass::$content E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php 45
ERROR - 2019-08-19 12:35:26 --> Severity: Notice --> Undefined property: stdClass::$content E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php 53
ERROR - 2019-08-19 12:35:26 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:35:42 --> Severity: Notice --> Undefined property: stdClass::$content E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php 53
ERROR - 2019-08-19 12:35:42 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:36:05 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:37:11 --> Severity: Parsing Error --> syntax error, unexpected '">' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ';' E:\xamp\htdocs\pharma\application\views\admin\courseDetails.php 49
ERROR - 2019-08-19 12:37:26 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:38:11 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:39:02 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:47:36 --> Query error: Unknown column 'dbdriver' in 'field list' - Invalid query: UPDATE `course` SET `dbdriver` = 'mysqli', `compress` = 0, `delete_hack` = 1, `stricton` = 0, `_escape_char` = '`', `return_delete_sql` = 0, `reset_delete_data` = 0, `qb_distinct` = 0, `qb_limit` = 0, `qb_offset` = 0, `qb_where_group_started` = 0, `qb_where_group_count` = 0, `qb_caching` = 0, `dsn` = '', `username` = 'root', `password` = '', `hostname` = 'localhost', `database` = 'pharma', `subdriver` = NULL, `dbprefix` = '', `char_set` = 'utf8', `dbcollat` = 'utf8_general_ci', `encrypt` = 0, `swap_pre` = '', `port` = NULL, `pconnect` = 0, `result_id` = 0, `db_debug` = 1, `benchmark` = 0, `query_count` = 0, `bind_marker` = '?', `save_queries` = 1, `trans_enabled` = 1, `trans_strict` = 1, `_trans_depth` = 0, `_trans_status` = 1, `_trans_failure` = 0, `cache_on` = 0, `cachedir` = '', `cache_autodel` = 0, `CACHE` = NULL, `_protect_identifiers` = 1, `_like_escape_str` = ' ESCAPE \'%s\' ', `_like_escape_chr` = '!', `_count_string` = 'SELECT COUNT(*) AS '
WHERE `id` = '1'
ERROR - 2019-08-19 12:47:59 --> Query error: Unknown column 'dbdriver' in 'field list' - Invalid query: UPDATE `course` SET `dbdriver` = 'mysqli', `compress` = 0, `delete_hack` = 1, `stricton` = 0, `_escape_char` = '`', `return_delete_sql` = 0, `reset_delete_data` = 0, `qb_distinct` = 0, `qb_limit` = 0, `qb_offset` = 0, `qb_where_group_started` = 0, `qb_where_group_count` = 0, `qb_caching` = 0, `dsn` = '', `username` = 'root', `password` = '', `hostname` = 'localhost', `database` = 'pharma', `subdriver` = NULL, `dbprefix` = '', `char_set` = 'utf8', `dbcollat` = 'utf8_general_ci', `encrypt` = 0, `swap_pre` = '', `port` = NULL, `pconnect` = 0, `result_id` = 0, `db_debug` = 1, `benchmark` = 0, `query_count` = 0, `bind_marker` = '?', `save_queries` = 1, `trans_enabled` = 1, `trans_strict` = 1, `_trans_depth` = 0, `_trans_status` = 1, `_trans_failure` = 0, `cache_on` = 0, `cachedir` = '', `cache_autodel` = 0, `CACHE` = NULL, `_protect_identifiers` = 1, `_like_escape_str` = ' ESCAPE \'%s\' ', `_like_escape_chr` = '!', `_count_string` = 'SELECT COUNT(*) AS '
WHERE `id` = '1'
ERROR - 2019-08-19 12:55:05 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:55:48 --> Query error: Unknown column 'dbdriver' in 'field list' - Invalid query: UPDATE `course` SET `dbdriver` = 'mysqli', `compress` = 0, `delete_hack` = 1, `stricton` = 0, `_escape_char` = '`', `return_delete_sql` = 0, `reset_delete_data` = 0, `qb_distinct` = 0, `qb_limit` = 0, `qb_offset` = 0, `qb_where_group_started` = 0, `qb_where_group_count` = 0, `qb_caching` = 0, `dsn` = '', `username` = 'root', `password` = '', `hostname` = 'localhost', `database` = 'pharma', `subdriver` = NULL, `dbprefix` = '', `char_set` = 'utf8', `dbcollat` = 'utf8_general_ci', `encrypt` = 0, `swap_pre` = '', `port` = NULL, `pconnect` = 0, `result_id` = 0, `db_debug` = 1, `benchmark` = 0, `query_count` = 0, `bind_marker` = '?', `save_queries` = 1, `trans_enabled` = 1, `trans_strict` = 1, `_trans_depth` = 0, `_trans_status` = 1, `_trans_failure` = 0, `cache_on` = 0, `cachedir` = '', `cache_autodel` = 0, `CACHE` = NULL, `_protect_identifiers` = 1, `_like_escape_str` = ' ESCAPE \'%s\' ', `_like_escape_chr` = '!', `_count_string` = 'SELECT COUNT(*) AS '
WHERE `id` = '1'
ERROR - 2019-08-19 12:56:12 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:57:31 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:58:00 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:58:58 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:59:08 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:59:23 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 12:59:32 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 13:00:04 --> Severity: Notice --> Undefined variable: file_path E:\xamp\htdocs\pharma\application\controllers\Admin.php 213
ERROR - 2019-08-19 13:00:04 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 13:00:10 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 13:00:29 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 13:02:16 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 13:02:20 --> Severity: Notice --> Undefined variable: name E:\xamp\htdocs\pharma\application\controllers\Admin.php 190
ERROR - 2019-08-19 13:02:20 --> Severity: Notice --> Undefined variable: description E:\xamp\htdocs\pharma\application\controllers\Admin.php 190
ERROR - 2019-08-19 13:02:20 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 13:02:28 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 13:02:48 --> Severity: Notice --> Undefined variable: name E:\xamp\htdocs\pharma\application\controllers\Admin.php 190
ERROR - 2019-08-19 13:02:48 --> Severity: Notice --> Undefined variable: description E:\xamp\htdocs\pharma\application\controllers\Admin.php 190
ERROR - 2019-08-19 13:02:49 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 13:03:33 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 13:03:50 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 13:03:53 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 13:04:01 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 13:04:06 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 13:04:11 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 13:04:22 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 13:04:23 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 13:22:07 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 13:22:56 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 13:28:58 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 13:29:10 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 13:29:19 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 13:29:22 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 13:29:27 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 13:29:37 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 13:30:10 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 13:30:43 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 13:30:57 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 13:31:09 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 13:32:04 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 13:32:06 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 13:32:12 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 13:32:27 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 13:32:58 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 13:33:05 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 13:33:09 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 13:33:13 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 13:33:31 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 13:33:37 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 13:33:46 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 13:38:41 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 13:42:13 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 13:43:26 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 13:45:20 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 13:46:13 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 13:46:31 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 13:47:04 --> Severity: Error --> Call to undefined method CI_Session::destroy() E:\xamp\htdocs\pharma\application\controllers\Welcome.php 116
ERROR - 2019-08-19 13:47:26 --> Severity: Error --> Call to undefined method CI_Session::session_destroy() E:\xamp\htdocs\pharma\application\controllers\Welcome.php 116
ERROR - 2019-08-19 13:47:57 --> Severity: Warning --> Missing argument 1 for CI_Session::unset_userdata(), called in E:\xamp\htdocs\pharma\application\controllers\Welcome.php on line 116 and defined E:\xamp\htdocs\pharma\system\libraries\Session\Session.php 810
ERROR - 2019-08-19 13:47:57 --> Severity: Notice --> Undefined variable: key E:\xamp\htdocs\pharma\system\libraries\Session\Session.php 812
ERROR - 2019-08-19 13:47:57 --> Severity: Notice --> Undefined variable: key E:\xamp\htdocs\pharma\system\libraries\Session\Session.php 822
ERROR - 2019-08-19 13:48:19 --> Severity: Warning --> Missing argument 1 for CI_Session::unset_userdata(), called in E:\xamp\htdocs\pharma\application\controllers\Welcome.php on line 116 and defined E:\xamp\htdocs\pharma\system\libraries\Session\Session.php 810
ERROR - 2019-08-19 13:48:19 --> Severity: Notice --> Undefined variable: key E:\xamp\htdocs\pharma\system\libraries\Session\Session.php 812
ERROR - 2019-08-19 13:48:19 --> Severity: Notice --> Undefined variable: key E:\xamp\htdocs\pharma\system\libraries\Session\Session.php 822
ERROR - 2019-08-19 13:48:21 --> Severity: Warning --> Missing argument 1 for CI_Session::unset_userdata(), called in E:\xamp\htdocs\pharma\application\controllers\Welcome.php on line 116 and defined E:\xamp\htdocs\pharma\system\libraries\Session\Session.php 810
ERROR - 2019-08-19 13:48:21 --> Severity: Notice --> Undefined variable: key E:\xamp\htdocs\pharma\system\libraries\Session\Session.php 812
ERROR - 2019-08-19 13:48:21 --> Severity: Notice --> Undefined variable: key E:\xamp\htdocs\pharma\system\libraries\Session\Session.php 822
ERROR - 2019-08-19 13:51:49 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 13:51:50 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 13:51:50 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 13:51:50 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 13:51:50 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 13:51:50 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 13:51:50 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 13:51:50 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 13:51:50 --> 404 Page Not Found: Img/courses
ERROR - 2019-08-19 13:51:50 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 13:51:50 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 13:52:19 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 13:52:19 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 13:52:19 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 13:52:19 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 13:52:19 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 13:52:19 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 13:52:19 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 13:52:19 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 13:52:19 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 13:52:19 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 13:52:19 --> 404 Page Not Found: Img/courses
ERROR - 2019-08-19 13:53:35 --> Severity: Error --> Call to undefined method CI_Session::session_destroy() E:\xamp\htdocs\pharma\application\controllers\Welcome.php 117
ERROR - 2019-08-19 13:55:28 --> Severity: Error --> Call to undefined method CI_Session::session_destroy() E:\xamp\htdocs\pharma\application\controllers\Welcome.php 117
ERROR - 2019-08-19 13:55:30 --> Severity: Error --> Call to undefined method CI_Session::session_destroy() E:\xamp\htdocs\pharma\application\controllers\Welcome.php 117
ERROR - 2019-08-19 13:56:35 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 13:56:35 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 13:56:35 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 13:56:35 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 13:56:35 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 13:56:35 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 13:56:35 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 13:56:35 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 13:56:35 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 13:56:35 --> 404 Page Not Found: Img/courses
ERROR - 2019-08-19 13:56:55 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 13:56:55 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 13:56:55 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 13:56:55 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 13:56:55 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 13:56:55 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 13:56:55 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 13:56:55 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 13:56:55 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 13:56:55 --> 404 Page Not Found: Img/courses
ERROR - 2019-08-19 13:57:55 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 13:57:55 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 13:57:55 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 13:57:55 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 13:57:55 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 13:57:55 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 13:57:55 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 13:57:55 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 13:57:55 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 13:57:55 --> 404 Page Not Found: Img/courses
ERROR - 2019-08-19 13:57:55 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 13:58:06 --> 404 Page Not Found: Widget/index
ERROR - 2019-08-19 14:05:33 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 14:05:33 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 14:05:33 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 14:05:33 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 14:05:33 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 14:05:33 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 14:05:33 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 14:05:33 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 14:05:33 --> 404 Page Not Found: Img/courses
ERROR - 2019-08-19 14:05:33 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 14:05:33 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 14:07:05 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 14:11:14 --> Severity: Parsing Error --> syntax error, unexpected '}' E:\xamp\htdocs\pharma\application\controllers\Admin.php 237
ERROR - 2019-08-19 14:11:28 --> Severity: Parsing Error --> syntax error, unexpected '}' E:\xamp\htdocs\pharma\application\controllers\Admin.php 235
ERROR - 2019-08-19 14:11:31 --> Severity: Parsing Error --> syntax error, unexpected '}' E:\xamp\htdocs\pharma\application\controllers\Admin.php 235
ERROR - 2019-08-19 14:11:52 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 14:17:37 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 14:17:53 --> 404 Page Not Found: Widget/index
ERROR - 2019-08-19 15:29:36 --> 404 Page Not Found: Page/index
ERROR - 2019-08-19 15:32:03 --> Severity: Notice --> Undefined variable: menu E:\xamp\htdocs\pharma\application\views\admin\page.php 48
ERROR - 2019-08-19 15:32:03 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\pharma\application\views\admin\page.php 48
ERROR - 2019-08-19 15:32:03 --> Severity: Notice --> Undefined variable: content E:\xamp\htdocs\pharma\application\views\admin\page.php 60
ERROR - 2019-08-19 15:32:03 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\pharma\application\views\admin\page.php 60
ERROR - 2019-08-19 15:32:03 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 15:33:10 --> Severity: Notice --> Undefined variable: content E:\xamp\htdocs\pharma\application\views\admin\page.php 60
ERROR - 2019-08-19 15:33:10 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\pharma\application\views\admin\page.php 60
ERROR - 2019-08-19 15:33:10 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 15:34:05 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 15:34:54 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 15:35:27 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 15:36:37 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 15:39:42 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 15:57:24 --> Severity: Parsing Error --> syntax error, unexpected '$menu' (T_VARIABLE), expecting function (T_FUNCTION) E:\xamp\htdocs\pharma\application\controllers\Admin.php 258
ERROR - 2019-08-19 15:59:11 --> Severity: Warning --> Missing argument 2 for PharmaModel::addPage(), called in E:\xamp\htdocs\pharma\application\controllers\Admin.php on line 248 and defined E:\xamp\htdocs\pharma\application\models\PharmaModel.php 158
ERROR - 2019-08-19 15:59:11 --> Severity: Notice --> Undefined variable: data E:\xamp\htdocs\pharma\application\models\PharmaModel.php 159
ERROR - 2019-08-19 16:00:36 --> Query error: Unknown column 'Garage' in 'field list' - Invalid query: INSERT INTO `menu` (`Garage`) VALUES ('')
ERROR - 2019-08-19 16:01:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0, 1) VALUES ('name', 'Garage')' at line 1 - Invalid query: INSERT INTO `menu` (0, 1) VALUES ('name', 'Garage')
ERROR - 2019-08-19 16:04:14 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 16:04:51 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 16:05:20 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 16:05:30 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 16:07:10 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 16:07:25 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 16:08:18 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 16:09:26 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 16:13:54 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 16:17:07 --> 404 Page Not Found: Images/course-pic.jpg
ERROR - 2019-08-19 16:17:16 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 16:17:26 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 16:17:35 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 16:19:03 --> 404 Page Not Found: Images/course-pic.jpg
ERROR - 2019-08-19 16:25:08 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 16:25:34 --> 404 Page Not Found: Images/testi-pic-1.jpg
ERROR - 2019-08-19 16:25:34 --> 404 Page Not Found: Images/testi-pic-3.jpg
ERROR - 2019-08-19 16:25:34 --> 404 Page Not Found: Images/testi-pic-2.jpg
ERROR - 2019-08-19 16:25:34 --> 404 Page Not Found: Images/testi-pic-4.jpg
ERROR - 2019-08-19 16:25:34 --> 404 Page Not Found: Images/testi-pic-6.jpg
ERROR - 2019-08-19 16:25:35 --> 404 Page Not Found: Images/testi-pic-5.jpg
ERROR - 2019-08-19 16:29:16 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 16:29:48 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 16:29:48 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 16:29:48 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 16:29:48 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 16:29:48 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 16:29:48 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 16:29:48 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 16:29:49 --> 404 Page Not Found: Img/courses
ERROR - 2019-08-19 16:29:49 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 16:29:49 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 16:29:49 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 16:30:19 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 16:31:12 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 16:31:38 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 16:32:20 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 16:33:20 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 16:33:54 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 16:34:20 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 16:35:22 --> 404 Page Not Found: Images/testi-pic-2.jpg
ERROR - 2019-08-19 16:35:22 --> 404 Page Not Found: Images/testi-pic-6.jpg
ERROR - 2019-08-19 16:35:22 --> 404 Page Not Found: Images/testi-pic-5.jpg
ERROR - 2019-08-19 16:35:22 --> 404 Page Not Found: Images/testi-pic-4.jpg
ERROR - 2019-08-19 16:35:22 --> 404 Page Not Found: Images/testi-pic-3.jpg
ERROR - 2019-08-19 16:41:24 --> Severity: Notice --> Undefined variable: courses E:\xamp\htdocs\pharma\application\views\admin\listpages.php 53
ERROR - 2019-08-19 16:41:24 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 16:45:04 --> Severity: Notice --> Undefined variable: content E:\xamp\htdocs\pharma\application\controllers\Admin.php 263
ERROR - 2019-08-19 16:45:04 --> Severity: Notice --> Undefined variable: courses E:\xamp\htdocs\pharma\application\views\admin\listpages.php 53
ERROR - 2019-08-19 16:45:04 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 16:46:04 --> Severity: Notice --> Undefined variable: courses E:\xamp\htdocs\pharma\application\views\admin\listpages.php 53
ERROR - 2019-08-19 16:46:04 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 16:47:31 --> Severity: Notice --> Undefined variable: courses E:\xamp\htdocs\pharma\application\views\admin\listpages.php 53
ERROR - 2019-08-19 16:47:31 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 16:49:51 --> Severity: Notice --> Undefined variable: pages E:\xamp\htdocs\pharma\application\views\admin\listpages.php 51
ERROR - 2019-08-19 16:49:52 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 16:50:18 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 16:52:36 --> Severity: Error --> Call to undefined method CI_Session::session_destroy() E:\xamp\htdocs\pharma\application\controllers\Welcome.php 117
ERROR - 2019-08-19 16:53:10 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 16:53:10 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 16:53:10 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 16:53:10 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 16:53:10 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 16:53:10 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 16:53:10 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 16:53:10 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 16:53:10 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 16:53:10 --> 404 Page Not Found: Img/courses
ERROR - 2019-08-19 16:53:10 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 16:55:07 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 16:55:07 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 16:55:07 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 16:55:07 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 16:55:07 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 16:55:07 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 16:55:07 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 16:55:07 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 16:55:07 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 16:55:07 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 16:55:07 --> 404 Page Not Found: Img/courses
ERROR - 2019-08-19 16:55:10 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 16:55:12 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 16:55:19 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 16:55:21 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 16:55:28 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 16:55:31 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 16:55:36 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 16:55:40 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 18:09:06 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 18:14:26 --> 404 Page Not Found: Indexhtml/index
ERROR - 2019-08-19 18:17:02 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 18:17:23 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 18:17:26 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 18:17:26 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 18:17:26 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 18:17:26 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-19 18:17:26 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 18:17:26 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 18:17:26 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 18:17:26 --> 404 Page Not Found: Img/courses
ERROR - 2019-08-19 18:17:26 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 18:17:26 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-19 18:17:26 --> 404 Page Not Found: Img/product
ERROR - 2019-08-19 18:17:32 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 18:17:38 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 18:20:19 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-19 18:24:33 --> 404 Page Not Found: Assets/admin
