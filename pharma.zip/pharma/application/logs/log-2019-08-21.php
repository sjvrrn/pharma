<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-08-21 03:21:36 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 03:21:40 --> 404 Page Not Found: Listwidget/index
ERROR - 2019-08-21 03:21:46 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 03:31:35 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-21 03:35:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-21 03:46:30 --> Severity: Compile Error --> Cannot redeclare Welcome::project() E:\xamp\htdocs\pharma\application\controllers\Welcome.php 78
ERROR - 2019-08-21 03:54:01 --> Severity: Notice --> Undefined variable: widget E:\xamp\htdocs\pharma\application\views\pharma\project.php 44
ERROR - 2019-08-21 03:54:01 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\pharma\project.php 44
ERROR - 2019-08-21 03:54:01 --> Severity: Notice --> Undefined variable: widget E:\xamp\htdocs\pharma\application\views\pharma\project.php 54
ERROR - 2019-08-21 03:54:01 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\pharma\project.php 54
ERROR - 2019-08-21 03:55:02 --> Severity: Notice --> Undefined variable: widget E:\xamp\htdocs\pharma\application\views\pharma\project.php 44
ERROR - 2019-08-21 03:55:02 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\pharma\project.php 44
ERROR - 2019-08-21 03:55:02 --> Severity: Notice --> Undefined variable: widget E:\xamp\htdocs\pharma\application\views\pharma\project.php 54
ERROR - 2019-08-21 03:55:02 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\pharma\project.php 54
ERROR - 2019-08-21 03:55:04 --> Severity: Notice --> Undefined variable: widget E:\xamp\htdocs\pharma\application\views\pharma\project.php 44
ERROR - 2019-08-21 03:55:04 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\pharma\project.php 44
ERROR - 2019-08-21 03:55:04 --> Severity: Notice --> Undefined variable: widget E:\xamp\htdocs\pharma\application\views\pharma\project.php 54
ERROR - 2019-08-21 03:55:04 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\pharma\project.php 54
ERROR - 2019-08-21 03:57:08 --> Severity: Notice --> Use of undefined constant file_path - assumed 'file_path' E:\xamp\htdocs\pharma\application\views\pharma\research.php 51
ERROR - 2019-08-21 03:57:08 --> Severity: Notice --> Use of undefined constant file_path - assumed 'file_path' E:\xamp\htdocs\pharma\application\views\pharma\research.php 51
ERROR - 2019-08-21 03:59:23 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-21 04:01:04 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-21 04:01:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-21 04:03:16 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 04:03:25 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 04:03:49 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 04:04:14 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 04:07:05 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 04:07:10 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 04:07:50 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 04:07:55 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 04:08:20 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 04:08:45 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 04:09:20 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 04:09:23 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 04:09:32 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 04:09:43 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 04:25:59 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 04:26:34 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 04:30:24 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 04:30:57 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 04:31:54 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 04:32:00 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 04:32:26 --> Severity: Parsing Error --> syntax error, unexpected 'max_size' (T_STRING) E:\xamp\htdocs\pharma\application\controllers\Admin.php 45
ERROR - 2019-08-21 04:33:34 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 04:33:59 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 04:34:32 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 04:34:57 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 04:40:07 --> Severity: Notice --> Undefined variable: file_path E:\xamp\htdocs\pharma\application\controllers\Admin.php 319
ERROR - 2019-08-21 04:41:34 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 04:43:17 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 04:48:56 --> Severity: Parsing Error --> syntax error, unexpected '=>' (T_DOUBLE_ARROW) E:\xamp\htdocs\pharma\application\controllers\Admin.php 319
ERROR - 2019-08-21 04:50:32 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 06:48:47 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 07:06:57 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 07:07:14 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 07:07:31 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 07:07:52 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 07:08:03 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 07:08:06 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 07:08:18 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 07:08:21 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 07:08:30 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 07:08:39 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 07:08:43 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 07:08:52 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 07:09:41 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 07:10:03 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 07:10:14 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 07:10:45 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 07:11:02 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 08:00:00 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 08:01:47 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 08:02:28 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 08:04:07 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 08:08:06 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 08:10:13 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 08:11:45 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 08:12:05 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 08:12:09 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 08:12:14 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 08:12:18 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 08:12:32 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 08:12:36 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 08:12:37 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 08:12:38 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 08:13:08 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 08:13:12 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 08:13:42 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 08:57:00 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 08:58:58 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 08:59:42 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 09:03:44 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 09:04:52 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 09:10:14 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 09:12:31 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 09:15:32 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-21 09:17:57 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-21 09:20:18 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 09:20:47 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-21 09:26:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-21 09:27:31 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-21 09:35:57 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 09:37:09 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 09:37:50 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 09:37:52 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 09:40:35 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 09:41:20 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 09:41:43 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-21 09:43:06 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-21 09:47:05 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 09:49:57 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 10:14:15 --> Severity: Parsing Error --> syntax error, unexpected '}' E:\xamp\htdocs\pharma\application\controllers\Admin.php 340
ERROR - 2019-08-21 10:14:32 --> Severity: Warning --> Missing argument 1 for PharmaModel::getwidgets(), called in E:\xamp\htdocs\pharma\application\controllers\Admin.php on line 338 and defined E:\xamp\htdocs\pharma\application\models\PharmaModel.php 207
ERROR - 2019-08-21 10:14:32 --> Severity: Parsing Error --> syntax error, unexpected '<' E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 34
ERROR - 2019-08-21 10:14:47 --> Severity: Parsing Error --> syntax error, unexpected '<' E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 34
ERROR - 2019-08-21 10:15:06 --> Severity: Parsing Error --> syntax error, unexpected '<' E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 34
ERROR - 2019-08-21 10:15:19 --> Severity: Error --> Call to undefined function pritn_r() E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 34
ERROR - 2019-08-21 10:15:19 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 10:15:30 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 11:04:56 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 11:05:11 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 11:08:08 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 55
ERROR - 2019-08-21 11:08:08 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 55
ERROR - 2019-08-21 11:08:08 --> Severity: Warning --> substr() expects parameter 3 to be long, string given E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 55
ERROR - 2019-08-21 11:08:08 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 55
ERROR - 2019-08-21 11:08:08 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 55
ERROR - 2019-08-21 11:08:08 --> Severity: Warning --> substr() expects parameter 3 to be long, string given E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 55
ERROR - 2019-08-21 11:08:08 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 55
ERROR - 2019-08-21 11:08:08 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 55
ERROR - 2019-08-21 11:08:08 --> Severity: Warning --> substr() expects parameter 3 to be long, string given E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 55
ERROR - 2019-08-21 11:08:09 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 11:10:56 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 56
ERROR - 2019-08-21 11:10:56 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 56
ERROR - 2019-08-21 11:10:56 --> Severity: Warning --> substr() expects parameter 3 to be long, string given E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 56
ERROR - 2019-08-21 11:10:56 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 57
ERROR - 2019-08-21 11:10:56 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 57
ERROR - 2019-08-21 11:10:56 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 56
ERROR - 2019-08-21 11:10:56 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 56
ERROR - 2019-08-21 11:10:56 --> Severity: Warning --> substr() expects parameter 3 to be long, string given E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 56
ERROR - 2019-08-21 11:10:56 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 57
ERROR - 2019-08-21 11:10:56 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 57
ERROR - 2019-08-21 11:10:56 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 56
ERROR - 2019-08-21 11:10:56 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 56
ERROR - 2019-08-21 11:10:56 --> Severity: Warning --> substr() expects parameter 3 to be long, string given E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 56
ERROR - 2019-08-21 11:10:56 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 57
ERROR - 2019-08-21 11:10:56 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 57
ERROR - 2019-08-21 11:10:57 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 11:11:26 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 56
ERROR - 2019-08-21 11:11:26 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 56
ERROR - 2019-08-21 11:11:26 --> Severity: Error --> Call to undefined function sub_str() E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 56
ERROR - 2019-08-21 11:11:26 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 11:11:47 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 56
ERROR - 2019-08-21 11:11:47 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 56
ERROR - 2019-08-21 11:11:47 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 57
ERROR - 2019-08-21 11:11:47 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 57
ERROR - 2019-08-21 11:11:47 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 56
ERROR - 2019-08-21 11:11:47 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 56
ERROR - 2019-08-21 11:11:47 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 57
ERROR - 2019-08-21 11:11:47 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 57
ERROR - 2019-08-21 11:11:47 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 56
ERROR - 2019-08-21 11:11:47 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 56
ERROR - 2019-08-21 11:11:47 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 57
ERROR - 2019-08-21 11:11:47 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 57
ERROR - 2019-08-21 11:11:47 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 11:12:24 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 56
ERROR - 2019-08-21 11:12:24 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 56
ERROR - 2019-08-21 11:12:24 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 57
ERROR - 2019-08-21 11:12:24 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 57
ERROR - 2019-08-21 11:12:24 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 56
ERROR - 2019-08-21 11:12:24 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 56
ERROR - 2019-08-21 11:12:24 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 57
ERROR - 2019-08-21 11:12:24 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 57
ERROR - 2019-08-21 11:12:24 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 56
ERROR - 2019-08-21 11:12:24 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 56
ERROR - 2019-08-21 11:12:24 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 57
ERROR - 2019-08-21 11:12:24 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 57
ERROR - 2019-08-21 11:12:24 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 11:22:18 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 56
ERROR - 2019-08-21 11:22:18 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 56
ERROR - 2019-08-21 11:22:18 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 57
ERROR - 2019-08-21 11:22:18 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 57
ERROR - 2019-08-21 11:22:18 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 56
ERROR - 2019-08-21 11:22:18 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 56
ERROR - 2019-08-21 11:22:18 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 57
ERROR - 2019-08-21 11:22:18 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 57
ERROR - 2019-08-21 11:22:18 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 56
ERROR - 2019-08-21 11:22:18 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 56
ERROR - 2019-08-21 11:22:18 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 57
ERROR - 2019-08-21 11:22:18 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 57
ERROR - 2019-08-21 11:22:19 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 11:22:33 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 56
ERROR - 2019-08-21 11:22:33 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 56
ERROR - 2019-08-21 11:22:33 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 57
ERROR - 2019-08-21 11:22:33 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 57
ERROR - 2019-08-21 11:22:33 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 56
ERROR - 2019-08-21 11:22:33 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 56
ERROR - 2019-08-21 11:22:33 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 57
ERROR - 2019-08-21 11:22:33 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 57
ERROR - 2019-08-21 11:22:33 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 56
ERROR - 2019-08-21 11:22:33 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 56
ERROR - 2019-08-21 11:22:33 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 57
ERROR - 2019-08-21 11:22:33 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 57
ERROR - 2019-08-21 11:22:34 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 11:22:50 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 56
ERROR - 2019-08-21 11:22:50 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 56
ERROR - 2019-08-21 11:22:50 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 57
ERROR - 2019-08-21 11:22:50 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 57
ERROR - 2019-08-21 11:22:50 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 56
ERROR - 2019-08-21 11:22:50 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 56
ERROR - 2019-08-21 11:22:50 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 57
ERROR - 2019-08-21 11:22:50 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 57
ERROR - 2019-08-21 11:22:50 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 56
ERROR - 2019-08-21 11:22:51 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 56
ERROR - 2019-08-21 11:22:51 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 57
ERROR - 2019-08-21 11:22:51 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 57
ERROR - 2019-08-21 11:22:51 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 11:24:17 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 56
ERROR - 2019-08-21 11:24:17 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 56
ERROR - 2019-08-21 11:24:17 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 57
ERROR - 2019-08-21 11:24:17 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 57
ERROR - 2019-08-21 11:24:17 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 56
ERROR - 2019-08-21 11:24:17 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 56
ERROR - 2019-08-21 11:24:17 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 57
ERROR - 2019-08-21 11:24:17 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 57
ERROR - 2019-08-21 11:24:17 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 56
ERROR - 2019-08-21 11:24:17 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 56
ERROR - 2019-08-21 11:24:17 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 57
ERROR - 2019-08-21 11:24:17 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 57
ERROR - 2019-08-21 11:24:17 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 11:25:41 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 59
ERROR - 2019-08-21 11:25:41 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 59
ERROR - 2019-08-21 11:25:41 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 60
ERROR - 2019-08-21 11:25:41 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 60
ERROR - 2019-08-21 11:25:41 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 59
ERROR - 2019-08-21 11:25:41 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 59
ERROR - 2019-08-21 11:25:41 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 60
ERROR - 2019-08-21 11:25:41 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 60
ERROR - 2019-08-21 11:25:41 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 59
ERROR - 2019-08-21 11:25:41 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 59
ERROR - 2019-08-21 11:25:41 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 60
ERROR - 2019-08-21 11:25:41 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 60
ERROR - 2019-08-21 11:25:41 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 11:25:48 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 59
ERROR - 2019-08-21 11:25:48 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 59
ERROR - 2019-08-21 11:25:48 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 60
ERROR - 2019-08-21 11:25:48 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 60
ERROR - 2019-08-21 11:25:48 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 59
ERROR - 2019-08-21 11:25:48 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 59
ERROR - 2019-08-21 11:25:48 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 60
ERROR - 2019-08-21 11:25:48 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 60
ERROR - 2019-08-21 11:25:48 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 59
ERROR - 2019-08-21 11:25:48 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 59
ERROR - 2019-08-21 11:25:48 --> Severity: Notice --> Undefined variable: p E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 60
ERROR - 2019-08-21 11:25:48 --> Severity: Notice --> Trying to get property of non-object E:\xamp\htdocs\pharma\application\views\admin\listwidget.php 60
ERROR - 2019-08-21 11:25:48 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 11:27:38 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 11:29:37 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 11:32:02 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 11:38:31 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 11:39:44 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 11:41:29 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 11:53:12 --> Severity: Notice --> Array to string conversion E:\xamp\htdocs\pharma\system\core\Loader.php 273
ERROR - 2019-08-21 11:53:12 --> Severity: error --> Exception: Unable to locate the model you have specified: Editwidget E:\xamp\htdocs\pharma\system\core\Loader.php 348
ERROR - 2019-08-21 11:53:53 --> Severity: Notice --> Array to string conversion E:\xamp\htdocs\pharma\system\core\Loader.php 273
ERROR - 2019-08-21 11:53:53 --> Severity: error --> Exception: Unable to locate the model you have specified: Editwidget E:\xamp\htdocs\pharma\system\core\Loader.php 348
ERROR - 2019-08-21 11:53:54 --> Severity: Notice --> Array to string conversion E:\xamp\htdocs\pharma\system\core\Loader.php 273
ERROR - 2019-08-21 11:53:54 --> Severity: error --> Exception: Unable to locate the model you have specified: Editwidget E:\xamp\htdocs\pharma\system\core\Loader.php 348
ERROR - 2019-08-21 11:53:55 --> Severity: Notice --> Array to string conversion E:\xamp\htdocs\pharma\system\core\Loader.php 273
ERROR - 2019-08-21 11:53:55 --> Severity: error --> Exception: Unable to locate the model you have specified: Editwidget E:\xamp\htdocs\pharma\system\core\Loader.php 348
ERROR - 2019-08-21 11:53:55 --> Severity: Notice --> Array to string conversion E:\xamp\htdocs\pharma\system\core\Loader.php 273
ERROR - 2019-08-21 11:53:55 --> Severity: error --> Exception: Unable to locate the model you have specified: Editwidget E:\xamp\htdocs\pharma\system\core\Loader.php 348
ERROR - 2019-08-21 11:58:20 --> Severity: Notice --> Array to string conversion E:\xamp\htdocs\pharma\system\core\Loader.php 273
ERROR - 2019-08-21 11:58:20 --> Severity: error --> Exception: Unable to locate the model you have specified: Editwidget E:\xamp\htdocs\pharma\system\core\Loader.php 348
ERROR - 2019-08-21 11:58:22 --> Severity: Notice --> Array to string conversion E:\xamp\htdocs\pharma\system\core\Loader.php 273
ERROR - 2019-08-21 11:58:22 --> Severity: error --> Exception: Unable to locate the model you have specified: Editwidget E:\xamp\htdocs\pharma\system\core\Loader.php 348
ERROR - 2019-08-21 11:59:55 --> Severity: Notice --> Array to string conversion E:\xamp\htdocs\pharma\system\core\Loader.php 273
ERROR - 2019-08-21 11:59:55 --> Severity: error --> Exception: Unable to locate the model you have specified: Editwidget E:\xamp\htdocs\pharma\system\core\Loader.php 348
ERROR - 2019-08-21 12:00:12 --> Severity: Notice --> Undefined variable: menu E:\xamp\htdocs\pharma\application\views\admin\editwidget.php 48
ERROR - 2019-08-21 12:00:13 --> Severity: Warning --> Invalid argument supplied for foreach() E:\xamp\htdocs\pharma\application\views\admin\editwidget.php 48
ERROR - 2019-08-21 12:00:14 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 12:00:57 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 12:01:54 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 12:02:26 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 12:02:31 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 12:02:44 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 12:03:34 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 12:16:47 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 12:17:24 --> Severity: Notice --> Undefined variable: file_path E:\xamp\htdocs\pharma\application\controllers\Admin.php 374
ERROR - 2019-08-21 12:22:43 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 12:23:15 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 12:27:02 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 12:27:17 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 12:27:55 --> Severity: Notice --> Undefined variable: file_path E:\xamp\htdocs\pharma\application\controllers\Admin.php 319
ERROR - 2019-08-21 12:27:55 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 12:28:37 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 12:29:13 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 12:29:38 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 12:29:57 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 12:32:17 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 12:32:46 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 12:38:20 --> Severity: Error --> Call to undefined function strip_slashes() E:\xamp\htdocs\pharma\application\controllers\Admin.php 381
ERROR - 2019-08-21 12:44:57 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 12:45:04 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 12:46:00 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 12:46:17 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 12:46:23 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 12:47:38 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 12:54:44 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 12:55:01 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 13:00:46 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 13:00:52 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 13:00:54 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 13:04:38 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 13:04:43 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 13:04:45 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 13:05:00 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 13:05:07 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 13:06:05 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 13:06:08 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 13:06:13 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 13:06:18 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 13:06:36 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 13:06:40 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 13:06:52 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 13:09:16 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 13:09:24 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 13:09:42 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 13:09:46 --> Severity: Warning --> Missing argument 1 for Admin::removewidget() E:\xamp\htdocs\pharma\application\controllers\Admin.php 399
ERROR - 2019-08-21 13:09:46 --> Severity: Notice --> Undefined variable: id E:\xamp\htdocs\pharma\application\controllers\Admin.php 399
ERROR - 2019-08-21 13:12:06 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 13:12:09 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 13:15:00 --> Query error: Table 'pharma.widget' doesn't exist - Invalid query: DELETE FROM `widget`
WHERE 4 IS NULL
ERROR - 2019-08-21 13:17:53 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 13:18:11 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 13:18:20 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 13:18:34 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 13:18:58 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 13:19:24 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 13:19:47 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 13:20:08 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 13:20:11 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 13:20:13 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 13:20:42 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 13:20:44 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 13:20:56 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 13:21:54 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 13:22:24 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 13:22:43 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 13:22:56 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 13:35:00 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 13:35:15 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 13:37:49 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 13:38:16 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 13:38:25 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-21 13:38:34 --> 404 Page Not Found: Assets/admin
