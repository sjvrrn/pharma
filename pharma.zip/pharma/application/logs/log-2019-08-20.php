<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2019-08-20 03:50:54 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 03:50:55 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-20 03:50:55 --> 404 Page Not Found: Img/product
ERROR - 2019-08-20 03:50:55 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-20 03:50:55 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-20 03:50:55 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-20 03:50:55 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-20 03:50:55 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-20 03:50:55 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-20 03:50:55 --> 404 Page Not Found: Img/product
ERROR - 2019-08-20 03:50:55 --> 404 Page Not Found: Img/courses
ERROR - 2019-08-20 03:51:07 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 04:02:16 --> Severity: Parsing Error --> syntax error, unexpected 'page' (T_STRING) E:\xamp\htdocs\pharma\application\controllers\Admin.php 268
ERROR - 2019-08-20 04:10:38 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) E:\xamp\htdocs\pharma\application\controllers\Admin.php 265
ERROR - 2019-08-20 04:11:04 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) E:\xamp\htdocs\pharma\application\controllers\Admin.php 265
ERROR - 2019-08-20 04:11:18 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 04:13:37 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 04:14:11 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 04:15:36 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 04:15:58 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 04:16:01 --> 404 Page Not Found: Admin/editpage
ERROR - 2019-08-20 04:16:54 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 04:17:07 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 04:17:27 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 04:17:29 --> 404 Page Not Found: Admin/editpage
ERROR - 2019-08-20 04:27:53 --> Severity: Notice --> Use of undefined constant id - assumed 'id' E:\xamp\htdocs\pharma\application\views\admin\listpages.php 81
ERROR - 2019-08-20 04:27:54 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 04:27:56 --> 404 Page Not Found: Admin/editpage
ERROR - 2019-08-20 04:28:33 --> Severity: Notice --> Use of undefined constant id - assumed 'id' E:\xamp\htdocs\pharma\application\views\admin\listpages.php 81
ERROR - 2019-08-20 04:28:33 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 04:28:40 --> 404 Page Not Found: Admin/editpage
ERROR - 2019-08-20 04:30:25 --> Severity: Notice --> Use of undefined constant id - assumed 'id' E:\xamp\htdocs\pharma\application\views\admin\listpages.php 81
ERROR - 2019-08-20 04:30:25 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 04:30:32 --> 404 Page Not Found: Admin/editpage
ERROR - 2019-08-20 04:32:18 --> Severity: Notice --> Use of undefined constant id - assumed 'id' E:\xamp\htdocs\pharma\application\views\admin\listpages.php 81
ERROR - 2019-08-20 04:32:19 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 04:32:21 --> 404 Page Not Found: Admin/editpage
ERROR - 2019-08-20 04:33:01 --> Severity: Notice --> Use of undefined constant id - assumed 'id' E:\xamp\htdocs\pharma\application\views\admin\listpages.php 81
ERROR - 2019-08-20 04:33:01 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 04:33:03 --> 404 Page Not Found: Admin/editpage
ERROR - 2019-08-20 04:33:18 --> Severity: Notice --> Use of undefined constant id - assumed 'id' E:\xamp\htdocs\pharma\application\views\admin\listpages.php 81
ERROR - 2019-08-20 04:33:18 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 04:33:20 --> 404 Page Not Found: Admin/editpage
ERROR - 2019-08-20 04:33:29 --> Severity: Notice --> Use of undefined constant id - assumed 'id' E:\xamp\htdocs\pharma\application\views\admin\listpages.php 81
ERROR - 2019-08-20 04:33:30 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 04:33:32 --> 404 Page Not Found: Admin/editpage
ERROR - 2019-08-20 04:34:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' E:\xamp\htdocs\pharma\application\views\admin\listpages.php 81
ERROR - 2019-08-20 04:34:02 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 04:34:08 --> 404 Page Not Found: Admin/editpage
ERROR - 2019-08-20 04:35:05 --> Severity: Notice --> Use of undefined constant id - assumed 'id' E:\xamp\htdocs\pharma\application\views\admin\listpages.php 81
ERROR - 2019-08-20 04:35:05 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 04:35:11 --> 404 Page Not Found: Admin/editpage
ERROR - 2019-08-20 04:35:41 --> Severity: Notice --> Use of undefined constant id - assumed 'id' E:\xamp\htdocs\pharma\application\views\admin\listpages.php 81
ERROR - 2019-08-20 04:35:41 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 04:36:28 --> Severity: Notice --> Use of undefined constant id - assumed 'id' E:\xamp\htdocs\pharma\application\views\admin\listpages.php 81
ERROR - 2019-08-20 04:36:29 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 04:37:38 --> Severity: Notice --> Use of undefined constant id - assumed 'id' E:\xamp\htdocs\pharma\application\views\admin\listpages.php 81
ERROR - 2019-08-20 04:37:38 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 04:38:54 --> Severity: Notice --> Use of undefined constant id - assumed 'id' E:\xamp\htdocs\pharma\application\views\admin\listpages.php 81
ERROR - 2019-08-20 04:38:54 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 04:39:37 --> Severity: Notice --> Use of undefined constant id - assumed 'id' E:\xamp\htdocs\pharma\application\views\admin\listpages.php 81
ERROR - 2019-08-20 04:39:37 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 04:40:25 --> Severity: Notice --> Use of undefined constant id - assumed 'id' E:\xamp\htdocs\pharma\application\views\admin\listpages.php 81
ERROR - 2019-08-20 04:40:25 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 04:40:53 --> Severity: Notice --> Use of undefined constant id - assumed 'id' E:\xamp\htdocs\pharma\application\views\admin\listpages.php 81
ERROR - 2019-08-20 04:40:53 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 04:41:32 --> Severity: Notice --> Use of undefined constant id - assumed 'id' E:\xamp\htdocs\pharma\application\views\admin\listpages.php 81
ERROR - 2019-08-20 04:41:32 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 04:42:21 --> Severity: Notice --> Use of undefined constant id - assumed 'id' E:\xamp\htdocs\pharma\application\views\admin\listpages.php 81
ERROR - 2019-08-20 04:42:21 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 04:43:51 --> Severity: Notice --> Use of undefined constant id - assumed 'id' E:\xamp\htdocs\pharma\application\views\admin\listpages.php 81
ERROR - 2019-08-20 04:43:51 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 04:44:03 --> Severity: Notice --> Use of undefined constant id - assumed 'id' E:\xamp\htdocs\pharma\application\views\admin\listpages.php 81
ERROR - 2019-08-20 04:44:04 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 04:44:22 --> Severity: Notice --> Use of undefined constant id - assumed 'id' E:\xamp\htdocs\pharma\application\views\admin\listpages.php 81
ERROR - 2019-08-20 04:44:22 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 04:44:45 --> Severity: Notice --> Use of undefined constant id - assumed 'id' E:\xamp\htdocs\pharma\application\views\admin\listpages.php 81
ERROR - 2019-08-20 04:44:45 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 04:47:29 --> Severity: Notice --> Use of undefined constant id - assumed 'id' E:\xamp\htdocs\pharma\application\views\admin\listpages.php 81
ERROR - 2019-08-20 04:47:29 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 04:47:49 --> Severity: Notice --> Use of undefined constant id - assumed 'id' E:\xamp\htdocs\pharma\application\views\admin\listpages.php 81
ERROR - 2019-08-20 04:47:49 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 04:52:04 --> Severity: Notice --> Use of undefined constant id - assumed 'id' E:\xamp\htdocs\pharma\application\views\admin\listpages.php 81
ERROR - 2019-08-20 04:52:04 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 04:52:09 --> Severity: Notice --> Use of undefined constant id - assumed 'id' E:\xamp\htdocs\pharma\application\views\admin\listpages.php 81
ERROR - 2019-08-20 04:52:56 --> Severity: Notice --> Use of undefined constant id - assumed 'id' E:\xamp\htdocs\pharma\application\views\admin\listpages.php 81
ERROR - 2019-08-20 04:54:10 --> Severity: Notice --> Use of undefined constant id - assumed 'id' E:\xamp\htdocs\pharma\application\views\admin\listpages.php 81
ERROR - 2019-08-20 04:54:10 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 04:54:19 --> Severity: Notice --> Use of undefined constant id - assumed 'id' E:\xamp\htdocs\pharma\application\views\admin\listpages.php 81
ERROR - 2019-08-20 04:56:30 --> Severity: Notice --> Use of undefined constant id - assumed 'id' E:\xamp\htdocs\pharma\application\views\admin\listpages.php 81
ERROR - 2019-08-20 04:56:30 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 04:58:23 --> Severity: Notice --> Use of undefined constant id - assumed 'id' E:\xamp\htdocs\pharma\application\views\admin\listpages.php 81
ERROR - 2019-08-20 04:58:23 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 04:59:02 --> Severity: Notice --> Use of undefined constant id - assumed 'id' E:\xamp\htdocs\pharma\application\views\admin\listpages.php 81
ERROR - 2019-08-20 04:59:02 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 04:59:12 --> Severity: Notice --> Use of undefined constant id - assumed 'id' E:\xamp\htdocs\pharma\application\views\admin\listpages.php 81
ERROR - 2019-08-20 04:59:12 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 05:00:26 --> Severity: Notice --> Use of undefined constant id - assumed 'id' E:\xamp\htdocs\pharma\application\views\admin\listpages.php 81
ERROR - 2019-08-20 05:00:27 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 05:01:31 --> Severity: Notice --> Use of undefined constant id - assumed 'id' E:\xamp\htdocs\pharma\application\views\admin\listpages.php 81
ERROR - 2019-08-20 05:01:31 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 05:01:52 --> Severity: Notice --> Use of undefined constant id - assumed 'id' E:\xamp\htdocs\pharma\application\views\admin\listpages.php 81
ERROR - 2019-08-20 05:01:52 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 05:02:43 --> Severity: Notice --> Use of undefined constant id - assumed 'id' E:\xamp\htdocs\pharma\application\views\admin\listpages.php 81
ERROR - 2019-08-20 05:02:43 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 05:03:21 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 05:04:09 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 05:06:02 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 05:07:36 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 05:08:57 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 05:09:20 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 05:09:36 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 05:09:48 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 05:13:57 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 05:16:07 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 05:20:24 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 05:20:24 --> 404 Page Not Found: Img/product
ERROR - 2019-08-20 05:20:24 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-20 05:20:25 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-20 05:20:25 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-20 05:20:25 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-20 05:20:25 --> 404 Page Not Found: Assets/img
ERROR - 2019-08-20 05:20:25 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-20 05:20:25 --> 404 Page Not Found: Img/notification
ERROR - 2019-08-20 05:20:25 --> 404 Page Not Found: Img/courses
ERROR - 2019-08-20 05:20:25 --> 404 Page Not Found: Img/product
ERROR - 2019-08-20 05:21:49 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 05:22:25 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 05:22:25 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 05:22:43 --> 404 Page Not Found: Assets/admin
ERROR - 2019-08-20 07:51:11 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-20 07:53:21 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-20 07:59:34 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-20 08:00:37 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-20 08:00:38 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-20 08:02:09 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-20 08:02:14 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-20 08:02:17 --> 404 Page Not Found: Assets/css
ERROR - 2019-08-20 08:02:21 --> 404 Page Not Found: Assets/css
