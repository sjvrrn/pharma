<!DOCTYPE html>
<html lang="en">
<?require_once('head.php');?>
<body>
<?require_once('menu.php');?>
<div class="page-header">
  <div class="container">
    <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="page-section">
          <h1 class="page-title">404 Error</h1>
          <p class="page-text">Covering all aspects of Digital Marketing courses.</p>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="space-medium">
  <div class="container">
    <div class="row">
    <div class="col-lg-12 col-md-12 col-sm-6 col-xs-12">
    <div class="error">
    <h1>! 404 !</h1>
    <h2>THE PAGE NOT FOUND</h2>
    <p class="lead">UNFORTUNATELY THE PAGE YOU WERE LOOKING FOR COULD NOT BE FOUND. </p>
    </div>
      </div>
  </div>
</div>
</div>
<?require_once('footer.php');?>
</body>
</html>
