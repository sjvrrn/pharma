<!DOCTYPE html>
<html lang="en">
<? require_once('head.php');?>
<body>
  <? require_once('menu.php');?>
	<div class="space-medium">
        <div class="container">
            
          <?
          if($text){ foreach($text as $t){ $t = (object)$t; ?>
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-lg-12">
                    <div class="section-title">
                        <h4 class="text-left">Coures</h4>
                        <p class= p_cost><?=$t->content?> </p>
                    </div>
                </div>
            </div>

            <?} }else{?>
			<div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-lg-12">
                    <div class="section-title">
                        <h4 class="text-left">Coures</h4>
						<p class= p_cost>
						   Costarica is a dynamic , rapidly evolving organization that is working to meet the needs of the healthcare professionals and their patients.</p>
						<p class= p_cost> To ensure we can continue to deliver on our commitments to the customers who rely on us, we are focused on improving the way we do business; on operating with transparency in everything we do; and on listening to the views of all of the people involved in health care decisions. our goal is to ensure that people everywhere have access to innovative treatments and quality health care.
						</p>
                    </div>
                </div>
            </div>
        <? }?>
	
           
		  	
 <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-lg-12">
                   <h3 class="heading_cost">Our Cources</h3>
                   <!-- cources-start-->
                   <? if($courses){  $i=0; foreach($courses as $course){ $course = (object)$course;
                    if($i%3==0){ echo"</div><div class='row'>";}
                    ?>   
                                    
                   <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <div class="service-block ">
                            <div class="service-icon"><i class="icon-switches"></i></div>
                            <div class="service-content">
                                <h3><a href="#" class="course_title"><?=$course->name ?></a></h3>
                                <p><?=$course->description ?>.</p>
                                <a href="#" class="btn-link"> read more</a>
                            </div>
                        </div>
                    </div>

                <? $i++; }
                } ?>
               
                    <!-- cources-close-->
                </div>  
            </div>  
		
		</div>	
	    <!-- cources-close-->
    </div>
   <?php require_once('footer.php');?>
</body>

</html>