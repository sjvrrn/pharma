<!DOCTYPE html>
<html lang="en">
<? require_once('head.php');?>
<body>
  <? require_once('menu.php');?>
    <div class="contact-block">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"> </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-lg-offset-2 col-lg-8  col-md-offset-2 col-md-8 col-sm-12 col-xs-12">
                <div class="contact-form">
                    <h1 class="contact-info-title mb40 ">Hi, How Can We Help You?</h1>
                    <div class="row">
                        <form>
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label class="control-label sr-only " for="Name"></label>
                                    <input id="name" type="text" placeholder="Name" class="form-control" required>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label class="control-label sr-only " for="email"></label>
                                    <input id="email" type="text" placeholder="Email" class="form-control" required>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label class="control-label sr-only " for="Phone"></label>
                                    <input id="phone" type="text" placeholder="Phone" class="form-control" required>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label class="control-label sr-only " for="Subject"></label>
                                    <input id="subject" type="text" placeholder="Subject" class="form-control">
                                </div>
                            </div>
                            <div class="col-lg-12 col-md-12 col-sm-6 col-xs-12">
                                <div class="form-group">
                                    <label class="control-label sr-only" for="textarea"></label>
                                    <textarea class="form-control" id="textarea" name="textarea" rows="4" placeholder="Message"></textarea>
                                </div>
                            </div>
                            <div class="col-lg-12 col-md-12 col-sm-6 col-xs-12">
                                <button class="btn btn-primary btn-lg mt30">Send us message</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="mb40">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-6 col-xs-12">
                    <div class="contact-info">
                        <h2 class="mb40">Our Contact Info</h2>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                        <div class="">
                            <div class="contact-icon"><i class="fa fa-map-marker"></i></div>
                            <div class="">
                                <p>2-22-311/171/C, ADDAGUTTA SOCIETY,H.M.T. COLONY,BALAJI NAGAR,KUKATPALLY, Hyderabad, Telangana, India,500072</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                        <div class="">
                            <div class="contact-icon"><i class="fa fa-phone"></i></div>
                            <div class="">
                                <p>+91 9999999999
                                    <br> +91 9999999999</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                        <div class="">
                            <div class="contact-icon"><i class="fa fa-envelope"></i></div>
                            <div class="">
                                <p>costaricapharma@gmail.com
                                    <br> info@costrica.com
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                        <div class="">
                            <div class="contact-icon"><i class="fa fa-mail-forward"></i></div>
                            <div class="">
                                <div class="contact-social"> <span><a href="#"><i class="fa fa-facebook"></i></a></span> <span><a href="#"><i class="fa fa-google-plus"></i></a></span> <span><a href="#" class="active"><i class="fa fa-twitter"></i></a> </span> <span><a href="#"><i class="fa fa-linkedin"></i></a> </span></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--
            <hr>
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-6 col-xs-12">
                    <h2 class="mb40">Our Offices</h2>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                    <div class="widget location">
                        <h3>Digitaledu, Delhi</h3>
                        <p>2829 Woodland Cherokee, IA 51012</p>
                        <ul>
                            <li><i class="fa fa-phone"></i>800-123-4567</li>
                            <li><i class="fa fa-envelope"></i>info@education.com</li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                    <div class="widget location">
                        <h3>Digitaledu, Mumbai</h3>
                        <p>2780 Radio Park DriveAthens, GA 30601</p>
                        <ul>
                            <li><i class="fa fa-phone"></i>800-123-4567</li>
                            <li><i class="fa fa-envelope"></i>info@education.com</li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                    <div class="widget location">
                        <h3>Digitaledu, Ahmedabad</h3>
                        <p>3506 Alfred DriveBrooklyn, NY 11226</p>
                        <ul>
                            <li><i class="fa fa-phone"></i>800-123-4567</li>
                            <li><i class="fa fa-envelope"></i>info@education.com</li>
                        </ul>
                    </div>
                </div>
            </div> -->
        </div>
    </div>
    <div class="cta-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-offset-2 col-lg-8 col-md-offset-2 col-md-8 col-sm-6 col-xs-12">
                    <div class="cta-block">
                        <h1>Ohh!! Have A Question?</h1>
                        <p class="cta-text">Velitconsectetur utleo velaoreet in bibendum felirbi iaculis iaculis dpibusectetur utlin bibendum.</p>
                        <a href="#" class="btn btn-primary btn-lg">Learn more</a> <a href="#" class="btn btn-default btn-lg">Contact us</a> </div>
                </div>
            </div>
        </div>
    </div>
   <?php require_once('footer.php');?>
</body>

</html>