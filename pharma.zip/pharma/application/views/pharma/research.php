<!DOCTYPE html>
<html lang="en">
<? require_once('head.php');?>
<style>
  #widget{
          border: 1px solid #057ec31a;
          padding: 1%;
          margin-bottom: 5px;
      }
</style>
<body>
   <? require_once('menu.php');?>
<? require_once('slider.php');?>
<div class="space-medium">
       <div class="container">
        <? if($text){
                foreach($text as $t){ $t = (object)$t;
                  echo' <div class="row">

                                 <div class="col-lg-12 col-md-12 col-sm-12 col-lg-12">
                                      <div class="section-title">
                                          <h4 class=" align-left">'.substr($t->content,0,30).'</h4>
                                             <p>'.$t->content.'</p>
                                     </div>
                                  </div>
                              </div>';

                }
          }else{?>  
                  <div class="row">

            <div class="col-lg-12 col-md-12 col-sm-12 col-lg-12">
                  <div class="section-title">
                      <h3>Career</h3>
                <p class= p_cost>
              At Costarica, we believe our employees are the reason for all our successes. Our future depends on our global community of employees whose varied perspectives, experiences and skills fuel the creativity for pharmaceutical innovation.
              </p>
             
                  </div>
              </div>
          </div>
            <hr>          
          <?} ?>
       
       </div>
    </div>
	<div class="space-medium">
    <div class="container">
        <? foreach($widgets as $widget){ $widget  = (object)$widget;?>
    <div class="row" id="widget">
      
        <?if($widget->alignment==1){ ?>
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
              <?=$widget->content?>
            </div>
         <? } ?>
           <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
             <div class="about-img">
               <img src="<?=base_url();?>uploads/<?=$widget->file_path?>"" alt="" class="img-responsive"> 
             </div>
          </div>
         <?if($widget->alignment==2){ ?>
          <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
            <?=$widget->content?>
          </div>
         <? } ?>
     
    </div>
    <? } ?>
    </div>
    </div>
    <div class="container">
    <hr>
    </div>
</div>

<!--cta-start-->
<div class="cta-section">
  <div class="container">
    <div class="row">
      <div class="col-lg-offset-2 col-lg-8 col-md-offset-2 col-md-8 col-sm-6 col-xs-12">
        <div class="cta-block">
          <h1>Ohh!! Have A Question?</h1>
          <p class="cta-text">Velitconsectetur utleo velaoreet in bibendum felirbi iaculis iaculis dpibusectetur utlin bibendum.</p>
          <a href="#" class="btn btn-primary btn-lg">Learn more</a> <a href="#" class="btn btn-default btn-lg">Contact us</a> </div>
      </div>
    </div>
  </div>
</div>

<? require_once('footer.php');?>
</body>

</html>