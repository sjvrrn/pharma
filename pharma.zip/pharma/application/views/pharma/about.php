<!DOCTYPE html>
<html lang="en">
<?require_once('head.php');?>
<body>
  <? require_once('menu.php');?>
  <?require_once('slider.php');?>
    <div class="space-medium">
        <div class="container">
          <? if($text){
                foreach($text as $t){ $t = (object)$t;
                  echo' <div class="row">

                                 <div class="col-lg-12 col-md-12 col-sm-12 col-lg-12">
                                      <div class="section-title">
                                          <h4 class=" align-left">'.substr($t->content,0,30).'</h4>
                                             <p>'.$t->content.'</p>
                                     </div>
                                  </div>
                              </div>';

                }
          }else{?>  
           <div class="row">

               <div class="col-lg-12 col-md-12 col-sm-12 col-lg-12">
                    <div class="section-title">
                        <h3 class="heading_cost">About US</h3>
                        <p class= p_cost>
                           Costarica is a branded Pharmaceutical company that has entered the market in 2018. Our Company brings a fresh and inventive approach to meet the unmet needs.
                       </p>
                       <p class= p_cost> Costarica is a fast growing organization established by a team of professionals with over decades of experience in the   
                        pharmaceutical industry with specific reference to service oriented .
                       </p>
                   </div>
                </div>
            </div>
            <hr>          
          <?} ?>
           
          <!--  <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-lg-12">
                    <div class="section-title">
                        <h3 class="heading_cost">Mission</h3>
                        <div class="courses">
                            <ul style="list-style-type:square">
                                <li>To be a true world class, transnational pharmaceutical company that provides distinctive    
                                   products services that save and improve lives.</li>
                                <li>To provide unsurpassed customer service.</li>
                                <li>Digital Marketing Team</li>
                                <li>To build and maintain strong relationships with the customers.</li>
                                <li>To build and maintain strong relationships with the customers.</li>
                            </ul>
                        </div>
                     </div>
                </div>
            </div>
            <hr>
            <div class="row">

                <div class="col-lg-12 col-md-12 col-sm-12 col-lg-12">
                    <div class="section-title">
                        <h3 class="heading_cost">Vision</h3>
                        <p class= p_cost>
                           Our vision is to emerge as technology driven global pharmaceutical company offering high quality and cost effective products.
                        </p>
                   
                    </div>
                </div>
            </div>
            <hr>
           <div class="row">

                <div class="col-lg-12 col-md-12 col-sm-12 col-lg-12">
                    <div class="section-title">
                        <h3 class="heading_cost">Our Value</h3>
                       <p class= p_cost>
                          Our company is devoted to the highest level of scientific brilliance and entrust our research in improving human health and quality of life. We endeavor to recognize the most significant needs of consumers and customers, and we dedicate our resources to meeting those needs. In discharging our responsibilities, we do not take professional or ethical shortcuts.
                       </p>
                   
                   </div>
                </div>
            </div>
            <hr>
            <div class="row">

                <div class="col-lg-12 col-md-12 col-sm-12 col-lg-12">
                    <div class="section-title">
                        <h3 class="heading_cost">Ethics</h3>
                        <p class= p_cost>
                           Our company has developed policies to ensure that all employees meet the highest ethical standards.
                        </p>
                        <p class= p_cost>
                           Our long-established core values guide us in all that we do:
                        </p>
                       <div class="courses">
                            <ul style="list-style-type:square">
                                <li> Integrity that embraces the very highest standards of honesty and ethical behavior </li>
                                <li> Excellence that is reflected in our continuous search for new ways to improve the performance of our business to become the best at what we do.</li>
                            
                            </ul>
                        </div>
                    </div>
                 </div>
           </div>
           <hr>
           <div class="row">

                <div class="col-lg-12 col-md-12 col-sm-12 col-lg-12">
                     <div class="section-title">
                        <h3 class="heading_cost">Why Us ?</h3>
                        <p class= p_cost>
                          Our core values are communication, empowerment, collaboration, honesty and integrity and innovation. We reflect these in the way we work. Our strict adherence to quality production and clients’ preferences has enabled us to establish a strong foothold in the market. Owing to the ethical business practices and transparent business dealings, we are successful to satisfy our clients in every possible manner.
                        </p>
                    </div>
                </div>
           </div> -->
            
            
       </div>
    </div>   
<?require_once('footer.php');?>  
</body>
</html>
