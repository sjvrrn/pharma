  <!-- footer start -->
    <div class="footer">
        <div class="container">
            <div class="row">
                <!-- footer-useful links-start -->
                <div class=" col-lg-3 col-md-3 col-sm-3 col-xs-12">
                    <div class="footer-widget">
                        <h3 class="footer-course_title">Quick Links</h3>
                        <ul>
                            <li><a href="index.html">Home </a></li>
                            <li><a href="about.html">About </a></li>
                            <li><a href="courses.html">Courses </a></li>
                            <li><a href="career.html">Carrer</a></li>
							<li><a href="#">Project Work</a></li>
                            <li><a href="services.html">Services </a></li>
                            <li> <a href="contact.html">Contact</a></li>
                        </ul>
                    </div>
                </div>
                <!-- footer-useful links-close -->
                <!-- footer-contactinfo-start -->
                <div class=" col-lg-4 col-md-4 col-sm-4 col-xs-12">
                    <div class="footer-widget">
                        <h3 class="footer-course_title">24 X 7 Support</h3>
                        <div class="">
                            <ul>
                                <li> <i class="fa fa-map-marker"></i> Costarica Pharma</li>
                                <li><i class="fa fa-phone"></i>040-40205557</li>
                                <li><i class="fa fa-envelope"></i>costaricapharma@gmail.com</li>
                            </ul>
                        </div>
                        <a href="#" class="btn btn-primary btn-sm">request a Course</a></div>
                </div>
                <!-- footer-contactinfo-close -->
                <!-- footer-about-start -->
                <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12 ">
                    <div class="footer-widget">
                        <h3 class="footer-title">About Costrica Pharma</h3>
                        <p class= p_cost>Costarica is a branded Pharmaceutical company that has entered the market in 2018. Our Company brings a fresh and inventive approach to meet the unmet needs.</p>
                        <p class= p_cost>Costarica is a fast growing organization established by a team of professionals with over decades of experience in the pharmaceutical industry with specific reference to service oriented.</p>
                    </div>
                </div>
                <!-- footer-about-close -->
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 ">
                    <div class="footer-line"></div>
                </div>
                <div class="col-lg-8 col-md-8 col-sm-6 col-xs-12">
                    <p><small>All Rights Reserved ©. Sankaris 2019 </small>
                    </p>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                    <div class="footer-social">
                        <a href="#"><span><i class="fa fa-facebook"></i></span></a>
                        <a href="#"><span><i class="fa fa-google-plus"></i></span> </a>
                        <a href="#"><span class="active"><i class="fa fa-twitter"></i> </span></a>
                        <a href="#"><span><i class="fa fa-instagram"></i></span> </a>
                        <a href="#"><span><i class=" fa fa-pinterest"></i> </span></a>
                        <a href="#"><span><i class="fa fa-linkedin"></i></span></a> </div>
                </div>
            </div>
        </div>
        <!-- footer-address-close -->
    </div>
    <!-- footer close -->
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="<?php echo base_url();?>/assets/js/jquery.min.js" type="text/javascript"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<?php echo base_url();?>/assets/js/bootstrap.min.js" type="text/javascript"></script>
    <script src="<?php echo base_url();?>/assets/js/menumaker.js" type="text/javascript"></script>
    <script type="text/javascript" src="<?php echo base_url();?>/assets/js/jquery.sticky.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>/assets/js/sticky-header.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>/assets/js/owl.carousel.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>/assets/js/slider.js"></script>