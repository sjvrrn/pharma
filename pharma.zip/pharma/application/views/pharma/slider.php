  

  <div class="slider">
        <div class="owl-carousel owl-theme">
         <?  if($sliders){ foreach($sliders as $slider){ $slider = (object)$slider;?>
            <div class="item carousel carousel"> <img src="<?=base_url();?>uploads/<?=$slider->content?>" alt=""></div>
            <? } }else{
            ?>
            <div class="item carousel carousel"> <img src="<?=base_url();?>assets/images/slider-3.jpg" alt=""></div>
            <?
            }
            ?>
        </div>
    </div>