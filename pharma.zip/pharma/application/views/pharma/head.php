<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="keywords" content="">
    <title>Pharma</title>
    <!-- Bootstrap -->
    <link rel="shortcut icon" type="image/x-icon" href="<?=base_url();?>assets/admin/img/favicon.ico">
   <link href="<?=base_url();?>assets/css/bootstrap.min.css" rel="stylesheet">
    <!-- Style CSS -->
    <link href="<?=base_url();?>assets/css/style.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i" rel="stylesheet">
    <!-- FontAwesome CSS -->
    <link rel="stylesheet" type="text/css" href="<?=site_url();?>assets/css/fontello.css">
    <link href="<?=base_url();?>assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="<?=base_url();?>assets/css/owl.carousel.min.css" rel="stylesheet">
    <link href="<?=base_url();?>assets/css/owl.theme.default.css" rel="stylesheet">
    <link href="<?=base_url();?>assets/css/Extranal.css" rel="stylesheet">
 
</head>
<style>
    .container{
        font-family:serif !important;
    }
    .form-control{
        color:black !important;
    }
</style>
