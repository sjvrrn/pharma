<style>
  #login{
    text-align:left !important;
  }
</style>
  <div class="header-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-lg-1 col-sm-4 col-md-2 col-xs-12">
                    <div class="logo">
                        <a href="index.html"><img src="<?=base_url();?>assets/images/logo.png" class="img-responsive logo" alt=""></a>
                    </div>
                </div>
                <div class="col-lg-10 col-md-10 col-sm-8 col-xs-12">
                    <div class="navigation-wrapper">
                        <div id="navigation">
                            <ul>
                                <li><a href="<?=site_url('/');?>" title="">Home</a></li>
                                <li><a href="<?=site_url('about');?>" title="">About</a> </li>
                                <li class="has-sub"><a href="<?=site_url('course');?>" title="">Courses</a>
                                    <ul>
                                        <li><a href="<?=site_url('course');?>" title="">Course</a></li>
                                        <li><a href="<?=site_url('courseSingle');?>" title="">Courses1</a>
                                            <ul>
                                                <li><a href="<?=site_url('phd');?>" title="">PH.D </a></li>
                                                <li><a href="<?=site_url('mphil');?>" title="">M.PHILL</a></li>
                                        
                                            </ul>
                                        </li>
                                    </ul>
                                </li>
                                <li><a href="<?=site_url('careers');?>" title="">Carrer</a> </li>
                                
                                <li class="has-sub"><a href="<?=site_url('project');?>" title="">Project Work</a>
                                    <ul>
                                        <li><a href="<?=site_url('Research');?>" title="">Research work</a>
                                            <ul>
                                                <li><a href="<?=site_url('phd');?>" title="">PH.D </a></li>
                                                <li><a href="<?=site_url('mphil');?>" title="">M.PHILL</a></li>
                                        
                                            </ul>
                                        </li>
                                        <li><a href="<?=site_url('careers');?>" title=""> Project2</a></li>
                                    </ul>
                                </li>
                                <li class="has-sub"><a href="<?=site_url('services');?>" title="">Services</a>
                                    <ul>
                                        <li><a href="<?=site_url('regulatory');?>" title="">Regulatory</a>
                                            <ul>
                                                <li><a href="<?=site_url('phd');?>" title="">PH.D </a></li>
                                                <li><a href="<?=site_url('mphil');?>" title="">M.PHILL</a></li>
                                        
                                            </ul>
                                        
                                        </li>
                                        <li><a href="<?=site_url('dossiers_development');?>" title="">Dossier Development</a>
                                            <ul>
                                                <li><a href="<?=site_url('services');?>" title="">PH.D </a></li>
                                                <li><a href="<?=site_url('services');?>" title="">M.PHILL</a></li>
                                        
                                            </ul>
                                        
                                        </li>
                                        <li><a href="<?=site_url('regulatory_affairs');?>" title="">Regulatory Affairs </a>
                                           <ul>
                                                <li><a href="<?=site_url('services');?>" title="">PH.D </a></li>
                                                <li><a href="<?=site_url('services');?>" title="">M.PHILL</a></li>
                                        
                                            </ul>
                                        </li>
                                        <li><a href="<?=site_url('core_segments');?>" title=""> Core Segments</a>
                                            <ul>
                                                <li><a href="<?=site_url('services');?>" title="">PH.D </a></li>
                                                <li><a href="<?=site_url('services');?>" title="">M.PHILL</a></li>
                                        
                                            </ul>
                                        
                                        </li>
                                    </ul>
                                </li>
                                <li><a href="<?=site_url('contact');?>" title="">More</a>
                                         <ul>
                                                <li><a href="<?=site_url('contact');?>" title="">contact</a></li>
                                                <li><a href="" title="" class="btn btn-primary text-left" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal" id="login">Login</a></li>
                                         </ul> 
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-1 hidden-md hidden-sm hidden-xs"> <a href="#" class="btn btn-primary">Request a Course</a> </div>
            </div>
        </div>
    </div>
<? if($this->session->flashdata('status')){
    echo"<div class='alert alert-success text-center'>".$this->session->flashdata('status')."</div>";
}
if(validation_errors())
    echo"<div class='alert alert-success text-center'>".validation_errors()."</div>";
 ?>

    <!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title text-center"><b>Login</b></h4>
      </div>
      <div class="modal-body">
          <!--form start-->
          <form class="form-horizontal" action="<?=site_url('login');?>" method="post">
              <div class="form-group">
                <label class="control-label col-sm-2" for="email">Email:</label>
                <div class="col-sm-10">
                  <input type="email" class="form-control" id="email"  name="email" placeholder="Enter email">
                </div>
              </div>
              <div class="form-group">
                <label class="control-label col-sm-2" for="pwd">Password:</label>
                <div class="col-sm-10"> 
                  <input type="password" class="form-control" id="pwd" placeholder="Enter password" name="password">
                </div>
              </div>
              <div class="form-group"> 
                <div class="col-sm-offset-2 col-sm-10">
                  <button type="submit" class="btn btn-default" name="login">Login</button>
                </div>
              </div>
          </form>
          <!--end-->
      </div>
    <!--   <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div> -->
    </div>

  </div>
</div>