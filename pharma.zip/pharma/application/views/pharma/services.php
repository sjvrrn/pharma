<!DOCTYPE html>
<html lang="en">
<? require_once('head.php');?>
<body>
   <? require_once('menu.php');?>
<? require_once('slider.php');?>
<div class="space-medium">
       <div class="container">
        <? if($text){
                foreach($text as $t){ $t = (object)$t;
                  echo' <div class="row">

                                 <div class="col-lg-12 col-md-12 col-sm-12 col-lg-12">
                                      <div class="section-title">
                                          <h4 class=" align-left">'.substr($t->content,0,30).'</h4>
                                             <p>'.$t->content.'</p>
                                     </div>
                                  </div>
                              </div>';

                }
          }else{?>  
                 <div class="row">

                  <div class="col-lg-12 col-md-12 col-sm-12 col-lg-12">
                      <div class="section-title">
                          <h3>Career</h3>
                    <p class= p_cost>
                  At Costarica, we believe our employees are the reason for all our successes. Our future depends on our global community of employees whose varied perspectives, experiences and skills fuel the creativity for pharmaceutical innovation.
                  </p>
                 
                      </div>
                  </div>
              </div>
            <hr>          
          <?} ?>
       
       </div>
    </div>

    <div class="space-medium">
    <div class="container">
    <div class="row">

      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
      
        <div class="pdtb40">
          <h1 class="mb30">Scope of Work</h1>
          
          <div class="courses">
          <ul>
            <li><i class="fa fa-circle-o"> </i>Drafting and Editing all sections of DMF</li>
            <li><i class="fa fa-circle-o"> </i>Documentation of the following</li>
            <li><i class="fa fa-circle-o"> </i>Drug Substance Characterization</li>
            <li><i class="fa fa-circle-o"> </i>Drug Substance Characterization</li>
            <li><i class="fa fa-circle-o"> </i>Stability Study</li>
            <li><i class="fa fa-circle-o"> </i>Product Development Reports (PDR)</li>
            <li><i class="fa fa-circle-o"> </i>Process Validation Protocol and Reports</li>
            <li><i class="fa fa-circle-o"> </i>Method Validation Protocol and Reports</li>
            <li><i class="fa fa-circle-o"> </i>Technology Transfer</li>
            <li><i class="fa fa-circle-o"> </i>Chemistry, Manufacture and Control (CMC) information</li>
          </ul>
        </div>
        </div>
      </div>
      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
        <div class="about-img"><img src="<?=base_url();?>assets/images/about-img.jpg" alt="" class="img-responsive">   
        </div>
      </div>
    </div>
  
    </div>
    </div>
    <div class="container">
    <hr>
    </div>
      <div class="space-medium">
      <div class="container">
    <div class="row">
      
        <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
          <div class="about-img mb30"><img src="<?=base_url();?>assets/images/about-pic.jpg" alt="" class="img-responsive"> </div>
        </div>
      
      <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
        <h1 class="mb30">Expertise Offered In</h1>
        
        <div class="courses">
          <ul>
            <li><i class="fa fa-circle-o"> </i>Abbreviated New Drug Application (ANDA) - US</li>
            <li><i class="fa fa-circle-o"> </i>European Union Registration - EU</li>
            <li><i class="fa fa-circle-o"> </i>Medicines & Healthcare Products Regulatory Agency (MHRA) - UK</li>
            <li><i class="fa fa-circle-o"> </i>Therapeutic Goods Administration (TGA) - Australia</li>
            <li><i class="fa fa-circle-o"> </i>Medicines Control Council (MCC) - South Africa</li>
            <li><i class="fa fa-circle-o"> </i>Commonwealth of Independent States (CIS) Registration</li>
            <li><i class="fa fa-circle-o"> </i>Registration in all other Regions across the globe</li>
          </ul>
        </div>
      </div>
    </div>
    </div>
  </div>
</div>

<!--cta-start-->
<div class="cta-section">
  <div class="container">
    <div class="row">
      <div class="col-lg-offset-2 col-lg-8 col-md-offset-2 col-md-8 col-sm-6 col-xs-12">
        <div class="cta-block">
          <h1>Ohh!! Have A Question?</h1>
          <p class="cta-text">Velitconsectetur utleo velaoreet in bibendum felirbi iaculis iaculis dpibusectetur utlin bibendum.</p>
          <a href="#" class="btn btn-primary btn-lg">Learn more</a> <a href="#" class="btn btn-default btn-lg">Contact us</a> </div>
      </div>
    </div>
  </div>
</div>

<? require_once('footer.php');?>
</body>

</html>