<!DOCTYPE html>
<html lang="en">
<?require_once('head.php');?>
<body>
<? require_once('menu.php');?>
<div class="page-header">
  <div class="container">
    <div class="row">
      <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="page-section">
          <h1 class="page-title">Client Reviews</h1>
          <p class="page-text">What our client speak about us.</p>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="space-medium">
  <div class="container">
    <div class="row"> 
      <!--review-1-start-->
      <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
        <div class="testimonial-block  ">
          <div class="testimonial-content">
            <p class="testimonial-text">“Nunc luctus fringilla tincidunt isn Fusce varius est eget gravida ones interdum Integer facilisis sit amets risus sed molliaecenas magna one ante, lacinia quis elit et, auctor venenatis sapien.”</p>
          </div>
        </div>
        <div class="testimonial-pic mb40"><img src="<?=site_url()?>assets/images/testi-pic-1.jpg" alt="" class="img-circle"></div>
        <div class="testimonial-user">
          <h4> Michel joe</h4>
          <div class="testimonial-meta">(Web Devloper,Social Media Marketing)</div>
        </div>
      </div>
      
      <!--review-1-close--> 
      <!--review-1-start-->
      <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
        <div class="testimonial-block">
          <div class="testimonial-content">
            <p class="testimonial-text">“Morbi volutpat sollicitudin eleiend hendrerit aliquet nislnec tincidunts nulla nulla ullamcorperat dictumse interdumsit etexd consectetur nibh idante tempus facilisiroin convallis mauris vitae tortor tempor.” </p>
          </div>
        </div>
        <div class="testimonial-pic  mb40"><img src="<?=site_url()?>assets/images/testi-pic-2.jpg" alt="" class="img-circle"></div>
        <div class="testimonial-user">
          <h4>Jodi Conner</h4>
          <div class="testimonial-meta">(Web Devloper)</div>
        </div>
      </div>
      
      <!--review-1-close--> 
      
      <!--review-1-start-->
      <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
        <div class="testimonial-block ">
          <div class="testimonial-content">
            <p class="testimonial-text">“Interdum et malesuada famesac ante ipsum misin faucibus uspeisse accumsan mollis orcied scele lrem sitamet enim condimenta sagittise justo egestauis sed tempus velit on Aenean vitae porttitor diam.”</p>
          </div>
        </div>
        <div class="testimonial-pic mb40"><img src="<?=site_url()?>assets/images/testi-pic-3.jpg" alt="" class="img-circle"></div>
        <div class="testimonial-user">
          <h4>Clyde Kirk</h4>
          <div class="testimonial-meta">(President, SEO)</div>
        </div>
      </div>
      </div>
      <!--review-1-close--> 
      <div class="row">

      <!--review-1-start-->
      <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
        <div class="testimonial-block ">
          <div class="testimonial-content">
            <p class="testimonial-text">“Maecenas pretium leoacmsa ones dictum dictmlass aptenciti loremse sociosqu adlitora torqueper conbia nostra, per incepimenaeosam non odio nisulla facilisvamus nullae on ornareon tristiquentumsite”</p>
          </div>
        </div>
        <div class="testimonial-pic"><img src="<?=site_url()?>assets/images/testi-pic-4.jpg" alt="" class="img-circle"></div>
        <div class="testimonial-user">
          <h4>Lendom Sirira</h4>
          <div class="testimonial-meta">(Dirctor, Social Media Marketing)</div>
        </div>
      </div>
      
      <!--review-1-close--> 
      
      <!--review-1-start-->
      <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
        <div class="testimonial-block ">
          <div class="testimonial-content">
            <p class="testimonial-text">“Donec porta in nulla inaliqueunce luctusnisi eget varius dignism odioi dolor sodales tortor vitae hdreritex purus a justoonec id blandit nullut convallis nislurabitur etnisid sem dignissim eleifend posuere”</p>
          </div>
        </div>
        <div class="testimonial-pic"><img src="<?=site_url()?>assets/images/testi-pic-5.jpg" alt="" class="img-circle"></div>
        <div class="testimonial-user">
          <h4>Srison Deo</h4>
          <div class="testimonial-meta">(Director Of Marlketing)</div>
        </div>
      </div>
      
      <!--review-1-close--> 
      
      <!--review-1-start-->
      <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
        <div class="testimonial-block ">
          <div class="testimonial-content">
            <p class="testimonial-text">“Rerdum et malesuada amesa ante ipsumisin aucibus seisse accuman mollis orcied scele lrem siamet one enim condimenta sagittise justo is egesuis sed tempus velit on lorem Aenean vitae porttitor ”</p>
          </div>
        </div>
        <div class="testimonial-pic"><img src="<?=site_url()?>assets/images/testi-pic-6.jpg" alt="" class="img-circle"></div>
        <div class="testimonial-user">
          <h4>Linda Recon</h4>
          <div class="testimonial-meta">(Manager, Web Analytics)</div>
        </div>
      </div>
      
      <!--review-1-close--> 
      
    </div>
  </div>
</div>
<div class="cta-section">
  <div class="container">
    <div class="row">
      <div class="col-lg-offset-2 col-lg-8 col-md-offset-2 col-md-8 col-sm-6 col-xs-12">
        <div class="cta-block">
          <h1>Ohh!! Have A Question?</h1>
          <p class="cta-text">Velitconsectetur utleo velaoreet in bibendum felirbi iaculis iaculis dpibusectetur utlin bibendum.</p>
          <a href="#" class="btn btn-primary btn-lg">Learn more</a> <a href="#" class="btn btn-default btn-lg">Contact us</a> </div>
      </div>
    </div>
  </div>
</div>
<? require_once('footer.php');?>
</body>
</html>
