<!DOCTYPE html>
<html lang="en">

<?require_once('head.php');?>
<body>
   <?require_once('menu.php');?>
    <div class="page-header">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="page-section">
                        <h1 class="page-title">Web Analytics</h1>
                        <p class="page-text">Expanding reach, generating leads and acquire customers.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="space-medium">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-6 col-xs-12">
                    <p class="lead">Are you interested in expanding reach generating leads and acquire customers using Digital Marketing including Mobile. Trained 100000+ professionals from 10,000+ clients in 500+ trainings across india. vitaeraesent pretium ultrices estsed tinduonec a dui scelerisque pharetra estsed hendrerit nunce. </p>
                </div>
            </div>
            <div class="row">
                <div class="mt40">
                    <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12"> <img src="./images/course-pic.jpg" alt="" class="img-responsive"> </div>
                    <div class="col-lg-1 col-md-1 col-sm-1 col-xs-12"></div>
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <p>Curabitur aliquet lacinia liberone sitat lucturaed mimagnaibus pellensque efcitur in luctus ut ntiam mattis nulla utsagittis porttitoed commodo nibh ut imperdiet tincidunt urna neque porttitor ligula quispharetra orcirisus iloremnon convallis tempoonec necauctor velite.</p>
                        <p>Phasellus tempor vehicula diameu vulputate In commodo diam nuncutes serblanditorci viverra inam fringilla lorem non convallis tempoc necactor velit,at tincidunt ligulatiam eget metus sed quam dictum sagittis veleu one ligulvamus et nulla etdiam viverrsuis neqt suscipite.</p>
                        <p>Phasellus tempor vehicula diameu vulputate In commodo diam nuncutes serblanditorci viverra inam fringilla lorem non convallis.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="space-medium bg-light ">
        <div class="container">
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                <div class="courses">
                    <h2 class="mb30">Who Should Attend This Training?</h2>
                    <ul>
                        <li><i class="fa fa-circle-o"> </i>Business Heads</li>
                        <li><i class="fa fa-circle-o"> </i>Sales &amp; Marketing Team</li>
                        <li><i class="fa fa-circle-o"> </i>Digital Marketing Team</li>
                        <li><i class="fa fa-circle-o"> </i>Web Design &amp; Development Team</li>
                        <li><i class="fa fa-circle-o"> </i>Sales &amp; Marketing Team</li>
                        <li><i class="fa fa-circle-o"> </i>Digital Marketing Team</li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                <div class="courses">
                    <h2 class="mb30">Special Features - Master 
          Certification Training</h2>
                    <ul>
                        <li><i class="fa fa-circle-o"> </i>Live Instructor-led Sessions</li>
                        <li><i class="fa fa-circle-o"> </i>Research Based Internship</li>
                        <li><i class="fa fa-circle-o"> </i>Hands-on Projects and Assignments</li>
                        <li><i class="fa fa-circle-o"> </i>Vivamus etnulla etdiam viverra pellenque.</li>
                        <li><i class="fa fa-circle-o"> </i>24X7 Trainer Support on Discussion Forum</li>
                        <li><i class="fa fa-circle-o"> </i>Vivamus etnulla etdiam viverra pellenque.</li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                <div class="widget-cta">
                    <h2 class="widget-cta-title">Register For Free 
          Orientation Session</h2>
                    <small>Limited Seats Available!</small>
                    <p class="mt20">15 July, 2017 (Sat)
                        <br> 3 PM to 4:30 PM (IST/GMT +5:30)</p>
                    <a href="#" class="btn btn-primary btn-lg">Request a Course</a> </div>
            </div>
        </div>
    </div>
    <div class="space-medium">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-6 col-xs-12">
                    <h1 class="mb60">Web Analytics Course Sessions</h1>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                    <div class="feature-blurb mb30">
                        <h3><strong>#1</strong> Module Introduction</h3>
                        <p>Nullam efficitur semper dapibusn euismod sodales lacuut vulputate est blandit nonuis.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                    <div class="feature-blurb mb30">
                        <h3><strong>#2</strong> Google Analytics</h3>
                        <p>Semper dapibusn euismod sodales lacuut vulputate est blandit nonuisullam efficitu.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                    <div class="feature-blurb mb30">
                        <h3><strong>#3</strong> Traffic Sources</h3>
                        <p>Aliquam at vestibulum ipsumrasid cursus ligula aliquam nibama nulla acsem lobortis suscipe.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                    <div class="feature-blurb ">
                        <h3><strong>#4</strong> Goal &amp; Ecommerce </h3>
                        <p>Ipsumrasid cursus ligula aliquam at vestibulum aliquam nibama nulla acsem lobortis dimsit.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                    <div class="feature-blurb ">
                        <h3><strong>#5</strong> Web analytics tools</h3>
                        <p>Vestibulum ipsumrasid cursus ligula aliquam nibama nulla acsem lobortis suscipeliquam at.</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                    <div class="feature-blurb ">
                        <h3><strong>#6</strong> Social media analytics </h3>
                        <p>Lorem sitmaet at vestibulum ipsumrasid cursus ligula aliquam nibama nulla acsem lobortimip.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="cta-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-offset-2 col-lg-8 col-md-offset-2 col-md-8 col-sm-6 col-xs-12">
                    <div class="cta-block">
                        <h1>Ohh!! Have A Question?</h1>
                        <p class="cta-text">Velitconsectetur utleo velaoreet in bibendum felirbi iaculis iaculis dpibusectetur utlin bibendum.</p>
                        <a href="#" class="btn btn-primary btn-lg">Learn more</a> <a href="#" class="btn btn-default btn-lg">Contact us</a> </div>
                </div>
            </div>
        </div>
    </div>
   <?require_once('footer.php');?>
</body>

</html>