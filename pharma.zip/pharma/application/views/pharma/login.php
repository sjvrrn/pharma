
<!DOCTYPE html>
<html lang="en">

<?php require_once('head.php');?>
<style>
    
    .form-control{  color:black !important; }
</style>
<body>
    <div class="header-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-lg-2 col-sm-4 col-md-2 col-xs-12">
                    <div class="logo">
                        <a href="index.html"><img src="<?php echo base_url();?>/assets/images/logo.png" class="img-responsive logo" alt=""></a>
                    </div>
                </div>
               <?php require_once('menu.php');?>
                <div class="col-lg-1 hidden-md hidden-sm hidden-xs"> <a href="#" class="btn btn-primary">Request a Course</a> </div>
            </div>
        </div>
    </div>
    <!-- header-close -->
    <!-- slider-start -->
    <div class="slider">
        <div class="owl-carousel owl-theme">
            <div class="item carousel carousel"> <img src="<?php echo base_url();?>/assets/images/slider-1.jpg" alt="">
            </div>
            <div class="item carousel carousel"><img src="<?php echo base_url();?>/assets/images/slider-2.jpg" alt="">
            </div>
            <div class="item carousel carousel"><img src="<?php echo base_url();?>/assets/images/slider-3.jpg" alt="">
            </div>
        </div>
    </div>

    <!--content-->
        <div class="container">
  <h5 class='text-center'><b>Login Form</b></h5>
  <form class="form-horizontal" action=" " method="post">
    <div class="form-group">
      <label class="control-label col-sm-6" for="email">Email:</label>
      <div class="col-sm-6">
        <input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-6" for="pwd">Password:</label>
      <div class="col-sm-6">          
        <input type="password" class="form-control" id="pwd" placeholder="Enter password" name="pwd">
      </div>
    </div>
   
    <div class="form-group">        
      <div class="col-sm-offset-6 col-sm-6">
        <button type="submit" class="btn btn-default" name="login">Submit</button>
      </div>
    </div>
  </form>
</div>
	<!--content end-->
  <?php  require_once('footer.php');?>
</body>

</html>
