<!DOCTYPE html>
<html lang="en">

<?require_once('head.php');?>

<body>
   <?require_once('menu.php');?>
    <!-- header-close -->
    <!-- slider-start -->
  
    <div class="space-medium">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-lg-12">
                    <div class="section-title">
                        <h3 class="heading_cost">Welcome To Costarica Pharma</h3>
                        <p class= p_cost>
                           Costarica is a dynamic , rapidly evolving organization that is working to meet the needs of the healthcare professionals and their patients.</p>
                        <p class= p_cost> To ensure we can continue to deliver on our commitments to the customers who rely on us, we are focused on improving the way we do business; on operating with transparency in everything we do; and on listening to the views of all of the people involved in health care decisions. our goal is to ensure that people everywhere have access to innovative treatments and quality health care.
                        </p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-lg-12">
                   <h3 class="heading_cost">Our Cources</h3>
                   <!-- cources-start-->
                   <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <div class="service-block ">
                            <div class="service-icon"><i class="icon-switches"></i></div>
                            <div class="service-content">
                                <h3><a href="#" class="course_title">Quality Control</a></h3>
                                <p>Curabitur aliquet lacinia libero one sitamet lucturaesent odio loremips veliconsectetu.</p>
                                <a href="#" class="btn-link"> read more</a>
                            </div>
                        </div>
                    </div>
                    <!-- cources-close-->
                    <!-- cources-start-->
                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                    <div class="service-block">
                        <div class="service-icon"><i class="icon-social-network"></i></div>
                        <div class="service-content">
                            <h3><a href="#" class="course_title">Stability</a></h3>
                            <p>Aliquam at vestibulum ipsumrasid cursus ligula aliquam nibama nulla acsem lobortis suscipe.</p>
                            <a href="#" class="btn-link"> read more</a> </div>
                    </div>
                </div>
                <!-- cources-close-->
                <!-- cources-start-->
                   <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <div class="service-block ">
                            <div class="service-icon"><i class="icon-switches"></i></div>
                            <div class="service-content">
                                <h3><a href="#" class="course_title">AR&D</a></h3>
                                <p>Curabitur aliquet lacinia libero one sitamet lucturaesent odio loremips veliconsectetu.</p>
                                <a href="#" class="btn-link"> read more</a>
                            </div>
                        </div>
                    </div>
                    <!-- cources-close-->
                    
                </div>  
            </div>  
            <div class="row">
            
                <!-- cources-start-->
                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                    <div class="service-block">
                        <div class="service-icon"><i class="icon-rate"></i></div>
                        <div class="service-content">
                            <h3><a href="#" class="course_title">Regulatory Affairs</a></h3>
                            <p>Nullam efficitur semper dapibusn euismod sodales lacuut vulputate est blandit nonuis.</p>
                            <a href="" class="btn-link"> read more</a> </div>
                    </div>
                </div>
                <!-- cources-close-->
                <!-- cources-start-->
                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                    <div class="service-block">
                        <div class="service-icon"><i class="icon-social-network"></i></div>
                        <div class="service-content">
                            <h3><a href="#" class="course_title">Validation</a></h3>
                            <p>Aliquam at vestibulum ipsumrasid cursus ligula aliquam nibama nulla acsem lobortis suscipe.</p>
                            <a href="#" class="btn-link"> read more</a> </div>
                    </div>
                </div>
                <!-- cources-close-->
                
                 <!-- cources-start-->
                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                    <div class="service-block">
                        <div class="service-icon"><i class="icon-social-network"></i></div>
                        <div class="service-content">
                            <h3><a href="#" class="course_title">Guidlines</a></h3>
                            <p>Aliquam at vestibulum ipsumrasid cursus ligula aliquam nibama nulla acsem lobortis suscipe.</p>
                            <a href="#" class="btn-link"> read more</a> </div>
                    </div>
                </div>
                <!-- cources-close-->
            </div>  
            
            <div class="row">
                <!-- cources-start-->
                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                    <div class="service-block">
                        <div class="service-icon"><i class="icon-social-network"></i></div>
                        <div class="service-content">
                            <h3><a href="#" class="course_title">Calibration</a></h3>
                            <p>Aliquam at vestibulum ipsumrasid cursus ligula aliquam nibama nulla acsem lobortis suscipe.</p>
                            <a href="#" class="btn-link"> read more</a> </div>
                    </div>
                </div>
                <!-- cources-close-->
                
                 <!-- cources-start-->
                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                    <div class="service-block">
                        <div class="service-icon"><i class="icon-social-network"></i></div>
                        <div class="service-content">
                            <h3><a href="#" class="course_title">Production</a></h3>
                            <p>Aliquam at vestibulum ipsumrasid cursus ligula aliquam nibama nulla acsem lobortis suscipe.</p>
                            <a href="#" class="btn-link"> read more</a> </div>
                    </div>
                </div>
                <!-- cources-close-->
            </div> 
        </div>  
        <!-- cources-close-->
    </div>
    
    <!-- footer start -->
<? require_once('footer.php');?>
</body>

</html>
