<!doctype html>
<html class="no-js" lang="en">

<? require_once('head.php'); ?>
<style>
    .container{
        font-family: serif !important;
    }
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<body>
<? require_once('sidebar.php'); ?>
    <!-- End Left menu area -->
    <!-- Start Welcome area -->
    <div class="all-content-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="logo-pro">
                        <a href="index.html"><img class="main-logo img-circle" src="<?=site_url();?>/assets/admin/img/logo/logo.png" alt="" /></a>
                    </div>
                </div>
            </div>
        </div>
       <? require_once('top.php');  ?>

<!--content start-->
      <div class="container">
<?
if(validation_errors())
    echo"<div class='alert alert-success'>".validation_errors()."</div>";
if($this->session->flashdata('status'))
    echo"<div class='alert alert-success'>".$this->session->flashdata('status')."</div>";
?>
<!--list tables-->
<!-- Editable table -->
<div class="card">
  <h3 class="card-header text-center font-weight-bold text-uppercase py-4">Courses List</h3>
  <div class="card-body">
    <div id="table" class="table-editable">
      <table class="table table-bordered table-responsive-md table-striped text-center">
        <thead>
          <tr>
            <th class="text-center">S.NO</th>
            <th class="text-center">page Name</th>
            <th class="text-center">Content</th>
            <th class="text-center">Profile_pic</th>
            <th class="text-center">Edit</th>
            <th class="text-center">Remove</th>
          </tr>
        </thead>
        <tbody>
          <?if($courses){if(count($courses)>0){ $i=1; foreach($courses as $c){ $c = (object)$c;?>
            <tr>
            <td class="pt-3-half" contenteditable="true"><?=$i?></td>
            <td class="pt-3-half" contenteditable="true"><?=$c->name?></td>
            <td class="pt-3-half" contenteditable="true">
              <?=$c->description?>
              </td>
            <td class="pt-3-half" contenteditable="true"><img class="img-responsive" src="<?=site_url()?>/uploads/<?=$c->file_path?>"></td> 
            <td class="pt-3-half">
              <span class="table-up"><a href="coursese/<?=base64_encode($c->id)?>" class="indigo-text"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a></span>
            </td>
            <td>
              <span class="table-remove"><a href="contente/<?=base64_encode($c->id)?>" type="button"
                  class="btn btn-danger btn-rounded btn-sm my-0">Remove</a></span>
            </td>
          </tr>
        <? $i++; }  }} ?>
          
        
        </tbody>
      </table>
    </div>
  </div>
</div>
<!-- Editable table -->
<!--end-->
      </div>

<!--end-->      
<? require_once('footer.php'); ?>
</body>

</html>