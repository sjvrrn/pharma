<!doctype html>
<html class="no-js" lang="en">
<style>
.footer {
  position: fixed;
 
}
</style>
<? require_once('head.php'); ?>
<style>
    .container{
        font-family: serif !important;
    }
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<body>
<? require_once('sidebar.php'); ?>
    <!-- End Left menu area -->
    <!-- Start Welcome area -->
    <div class="all-content-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="logo-pro">
                        <a href="index.html"><img class="main-logo img-circle" src="<?=site_url();?>/assets/admin/img/logo/logo.png" alt="" /></a>
                    </div>
                </div>
            </div>
        </div>
       <? require_once('top.php');  ?>

<!--content start-->
      <div class="container">
<?
if(validation_errors())
    echo"<div class='alert alert-success'>".validation_errors()."</div>";
if($this->session->flashdata('status'))
    echo"<div class='alert alert-success'>".$this->session->flashdata('status')."</div>";
?>
            <h4>AddCourse</h4>
             <form class="form-horizontal" action="" method="post" enctype="multipart/form-data">

              <div class="form-group" >
                <label class="control-label col-sm-4 col-md-4" for="email">Course Name</label>
                <div class="col-sm-4 col-md-4">
                  <input type="text" class="form-control" id="customFile" name="name" required>
                      </div>
                </div>
              <div class="form-group">
                <label class="control-label col-sm-4 col-md-4" for="pwd">Couser Description</label>
                <div class="col-sm-4 col-md-4"> 
                   <textarea class="form-control" rows="5" id="comment" name="description" ></textarea>
                </div>
              </div>

              <div class="form-group" id="file">
                <label class="control-label col-sm-4 col-md-4" for="email">CourseProfilePic</label>
                <div class="col-sm-4 col-md-4>
                  <div class="custom-file mb-3">
                      <input type="file" class="custom-file-input" id="customFile" name="file">
                      </div>
                </div>

              <div class="form-group"> 
                <div class="col-md-offset-4 col-sm-4">
                  <button type="submit" class="btn btn-default" name="addcourse">Submit</button>
                </div>
              </div>
          </form>

      </div>

<!--end-->      
<? require_once('footer.php'); ?>
</body>

</html>