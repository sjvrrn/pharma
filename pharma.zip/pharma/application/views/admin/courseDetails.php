<!doctype html>
<html class="no-js" lang="en">

<? require_once('head.php'); ?>
<style>
    .container{
        font-family: serif !important;
    }
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<body>
<? require_once('sidebar.php'); ?>
    <!-- End Left menu area -->
    <!-- Start Welcome area -->
    <div class="all-content-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="logo-pro">
                        <a href="index.html"><img class="main-logo img-circle" src="<?=site_url();?>/assets/admin/img/logo/logo.png" alt="" /></a>
                    </div>
                </div>
            </div>
        </div>
       <? require_once('top.php');  ?>

<!--content start-->
      <div class="container">
<?
if(validation_errors())
    echo"<div class='alert alert-success'>".validation_errors()."</div>";

if($this->session->flashdata('status')){
    echo"<div class='alert alert-success'>".$this->session->flashdata('status')."</div>";
}
  $details = (object)$details[0];

?>

             <form class="form-horizontal" action="" method="post" enctype="multipart/form-data">
              
               <div class="form-group" id="textcontent">
                <label class="control-label col-sm-4 col-md-4" for="pwd">Title:</label>
                <div class="col-sm-4 col-md-4"> 
                   <input type="text" class="form-control" rows="5" id="comment" name="title" value="<?=$details->name?>">
                </div>
              </div>
              <div class="form-group" id="textcontent">
                <label class="control-label col-sm-4 col-md-4" for="pwd">Content:</label>
                <div class="col-sm-4 col-md-4"> 
                   <textarea class="form-control" rows="5" id="comment" name="description"><?=$details->description?></textarea>
                </div>
              </div>
              <input type="hidden" name="id" value="<?=base64_decode($this->uri->segment(2))?>">
              <div class="form-group" id="file">
                <label class="control-label col-sm-4 col-md-4" for="email">Upload File</label>
                <div class="col-sm-4 col-md-4>
                  <div class="custom-file mb-3">
                      <input type="file" class="custom-file-input" id="customFile" name="file">
                      <img src="<?=site_url()?>uploads/<?=$details->file_path?>" alt="..." class="img-thumbnail">
                      </div>
                </div>

              <div class="form-group"> 
                <div class="col-md-offset-4 col-sm-4">
                  <button type="submit" class="btn btn-default" name="addSlide">Submit</button>
                </div>
              </div>
          </form>

      </div>

      <script>
          $(document).ready(function(){

            $(document).on('change','#type',function(){
              var type = parseInt($(this).val()); console.log(type+'=='+typeof(type));
              if(type == 2||type == 5){
                      $("#textcontent").css('display','block');
                      $("#file").css('display','none');
                     
              }else{
                      $("#file").css('display','block');
                      $("#textcontent").css('display','none');
              }

            });
          });
      </script>
<!--end-->      
<? require_once('footer.php'); ?>
</body>

</html>