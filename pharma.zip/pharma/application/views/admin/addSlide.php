<!doctype html>
<html class="no-js" lang="en">
<style>
.footer {
  position: fixed;
 
}
</style> 
<? require_once('head.php'); ?>
<style>
    .container{
        font-family: serif !important;
    }
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<body>
<? require_once('sidebar.php'); ?>
    <!-- End Left menu area -->
    <!-- Start Welcome area -->
    <div class="all-content-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="logo-pro">
                        <a href="index.html"><img class="main-logo img-circle" src="<?=site_url();?>/assets/admin/img/logo/logo.png" alt="" /></a>
                    </div>
                </div>
            </div>
        </div>
       <? require_once('top.php');  ?>

<!--content start-->
      <div class="container">
<?
if(validation_errors())
    echo"<div class='alert alert-success'>".validation_errors()."</div>";
if($this->session->flashdata('status'))
    echo"<div class='alert alert-success'>".$this->session->flashdata('status')."</div>";
?>

             <form class="form-horizontal" action="" method="post" enctype="multipart/form-data">

              <div class="form-group">
                  <label  class="control-label col-sm-4"for="sel1">Select list:</label>
                    <div class="col-sm-4">
                      <select class="form-control" id="menu" name="menu">
                        <option>Select Menu</option>
                       <?foreach($menu as $m){?>
                        <option value="<?= $m['id'];?>"><?= $m['name'];?></option>
                        <?}?>
                       
                      </select>
                    </div>
                </div>
                 <div class="form-group">
                  <label  class="control-label col-sm-4"for="sel1">Select list:</label>
                    <div class="col-sm-4">
                      <select class="form-control"  name="type" id="type">
                        <option>Select Content Type</option>
                       <?foreach($content as $c){?>
                        <option value="<?= $c['id'];?>"><?= $c['type'];?></option>
                        <?}?>
                       
                      </select>
                    </div>
                </div>


              <div class="form-group" id="file">
                <label class="control-label col-sm-4 col-md-4" for="email">Upload File</label>
                <div class="col-sm-4 col-md-4>
                  <div class="custom-file mb-3">
                      <input type="file" class="custom-file-input" id="customFile" name="file">
                      </div>
                </div>
              <div class="form-group" id="textcontent">
                <label class="control-label col-sm-4 col-md-4" for="pwd">Content:</label>
                <div class="col-sm-4 col-md-4"> 
                   <textarea class="form-control" rows="5" id="comment" name="content"></textarea>
                </div>
              </div>

              <div class="form-group"> 
                <div class="col-md-offset-4 col-sm-4">
                  <button type="submit" class="btn btn-default" name="addSlide">Submit</button>
                </div>
              </div>
          </form>

      </div>

      <script>
          $(document).ready(function(){

            $("#file").css('display','none');
            $('#textcontent').css('display','none');

            $(document).on('change','#type',function(){
              var type = parseInt($(this).val()); console.log(type+'=='+typeof(type));
              if(type == 2||type == 5){
                      $("#textcontent").css('display','block');
                      $("#file").css('display','none');
                     
              }else{
                      $("#file").css('display','block');
                      $("#textcontent").css('display','none');
              }

            });
          });
      </script>
<!--end-->      
<? require_once('footer.php'); ?>
</body>

</html>