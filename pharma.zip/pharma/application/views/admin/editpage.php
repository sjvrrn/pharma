<!doctype html>
<html class="no-js" lang="en">
<style>
.footer {
  position: fixed;
 
}
</style> 
<? require_once('head.php'); ?>
<style>
    .container{
        font-family: serif !important;
    }
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<body>
<? require_once('sidebar.php'); ?>
    <!-- End Left menu area -->
    <!-- Start Welcome area -->
    <div class="all-content-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="logo-pro">
                        <a href="index.html"><img class="main-logo img-circle" src="<?=site_url();?>/assets/admin/img/logo/logo.png" alt="" /></a>
                    </div>
                </div>
            </div>
        </div>
       <? require_once('top.php');  ?>

<!--content start-->
      <div class="container">
<?
if(validation_errors())
    echo"<div class='alert alert-success'>".validation_errors()."</div>";
if($this->session->flashdata('status'))
    echo"<div class='alert alert-success'>".$this->session->flashdata('status')."</div>";
  $page = (object)$page[0];

?>

             <form class="form-horizontal" action="" method="post" enctype="multipart/form-data">

              <div class="form-group">
                  <label  class="control-label col-sm-4"for="sel1">Select Parent:</label>
                    <div class="col-sm-4">
                      <select class="form-control" id="menu" name="menu">
                        <option>Select Menu</option>
                       <?foreach($menu as $m){?>
                        <option value="<?= $m['id'];?>"><?= $m['name'];?></option>
                        <?}?>
                       
                      </select>
                    </div>
                </div>
                 <div class="form-group">
                  <label  class="control-label col-sm-4"for="sel1">Page Name:</label>
                    <div class="col-sm-4">
                      <input type="text" class="form-control" id="customFile" name="name" required min_length="5">
                    </div>
                </div>
              <div class="form-group"> 
                <div class="col-md-offset-4 col-sm-4">
                  <button type="submit" class="btn btn-default" name="addSlide">Submit</button>
                </div>
              </div>
          </form>

      </div>
<!--end-->      
<? require_once('footer.php'); ?>
</body>

</html>