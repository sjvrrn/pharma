<!doctype html>
<html class="no-js" lang="en">
<style>
.footer {
  position: fixed;
 
}
</style> 
<? require_once('head.php'); ?>
<body>
<? require_once('sidebar.php'); ?>
    <!-- End Left menu area -->
    <!-- Start Welcome area -->
    <div class="all-content-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="logo-pro">
                        <a href="index.html"><img class="main-logo img-circle" src="<?=site_url();?>/assets/admin/img/logo/logo.png" alt="" /></a>
                    </div>
                </div>
            </div>
        </div>
       <? require_once('top.php'); ?>
<!--content start-->
       
<!--end-->      
<? require_once('footer.php'); ?>
</body>

</html>