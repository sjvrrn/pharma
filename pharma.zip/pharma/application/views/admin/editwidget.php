<!doctype html>
<html class="no-js" lang="en">
<!-- <style>
.footer {
  position: fixed;
 
}
</style> 
 --><? require_once('head.php'); ?>
 <script src="https://cdn.ckeditor.com/4.12.1/standard/ckeditor.js"></script>
<style>
    .container{
        font-family: serif !important;
    }
</style>
<body>
<? require_once('sidebar.php'); ?>
    <!-- End Left menu area -->
    <!-- Start Welcome area -->
    <div class="all-content-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="logo-pro">
                        <a href="index.html"><img class="main-logo img-circle" src="<?=site_url();?>/assets/admin/img/logo/logo.png" alt="" /></a>
                    </div>
                </div>
            </div>
        </div>
       <? require_once('top.php');  ?>

<!--content start-->
      <div class="container">
<?
if(validation_errors())
    echo"<div class='alert alert-success'>".validation_errors()."</div>";
if($this->session->flashdata('status'))
    echo"<div class='alert alert-success'>".$this->session->flashdata('status')."</div>";
?>

             <form class="form-horizontal" action="" method="post" enctype="multipart/form-data">

              <div class="form-group">
                  <label  class="control-label col-sm-4"for="sel1">Select list:</label>
                    <div class="col-sm-4">
                      <select class="form-control" id="menu" name="menu" disabled="disabled">
                        <option>Select Menu</option>
                       <?foreach($menu as $m){?>
                        <option <? if($widget->menuId == $m['id']) echo"selected"; ?> value="<?= $m['id'];?>"><?= $m['name'];?></option>
                        <?}?>
                      </select>
                    </div>
                </div>
              <div class="form-group" id="file">
                <label class="control-label col-sm-4 col-md-4" for="email">Upload File</label>
                <div class="col-sm-4 col-md-4>
                  <div class="custom-file mb-3">
                      <input type="file" class="custom-file-input" id="customFile" name="file">
                      <img src="<?=site_url();?>uploads/<?=$widget->file_path;?>" class="thumbnail">
                      </div>
                </div> 
              <input type="hidden" name="id" value="<?=$widget->id?>"> 
              <div class="form-group" id="textcontent">
                <label class="control-label col-sm-4 col-md-4" for="pwd">Content:</label>
                <div class="col-sm-8 col-md-8"> 
                    <textarea name="content"><?=str_replace("\\r\\n",'',$widget->content)?></textarea>
                <script>
                        CKEDITOR.replace( 'content' );
                </script>
                </div>
              </div>
               <div class="form-group">
                  <label  class="control-label col-sm-4"for="sel1">Text Alignment:</label>
                    <div class="col-sm-4">
                      <select class="form-control"  name="textalignment" id="type">
                        <option>Select Text Aligment</option>
                       <option value="1" <? if($widget->alignment==1)echo"selected";?>>Left</option>
                        <option value="2" <? if($widget->alignment==2)echo"selected";?>>Right</option>
                       </select>
                    </div>
                </div>
           
              <div class="form-group"> 
                <div class="col-md-offset-4 col-sm-4">
                  <button type="submit" class="btn btn-default" name="addSlide">Submit</button>
                </div>
              </div>
          </form>

      </div>
<!--end-->      
<? require_once('footer.php'); ?>
</body>
</html>