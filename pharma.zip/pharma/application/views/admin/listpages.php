<!doctype html>
<html class="no-js" lang="en">

<? require_once('head.php'); ?>
<style>
    .container{
        font-family: serif !important;
    }
</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<body>
<? require_once('sidebar.php'); ?>
    <!-- End Left menu area -->
    <!-- Start Welcome area -->
    <div class="all-content-wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="logo-pro">
                        <a href="index.html"><img class="main-logo img-circle" src="<?=site_url();?>/assets/admin/img/logo/logo.png" alt="" /></a>
                    </div>
                </div>
            </div>
        </div>
       <? require_once('top.php');  ?>

<!--content start-->
      <div class="container">
<?
if(validation_errors())
    echo"<div class='alert alert-success'>".validation_errors()."</div>";
if($this->session->flashdata('status'))
    echo"<div class='alert alert-success'>".$this->session->flashdata('status')."</div>";
?>
<!--list tables-->
<!-- Editable table -->
<div class="card">
  <h3 class="card-header text-center font-weight-bold text-uppercase py-4">Courses List</h3>
  <div class="card-body">
    <div id="table" class="table-editable">
      <table class="table table-bordered table-responsive-md table-striped text-center">
        <thead>
          <tr>
            <th class="text-center">S.NO</th>
            <th class="text-center">page Name</th>
            <th class="text-center">Edit</th>
            <th class="text-center">Remove</th>
          </tr>
        </thead>
        <tbody>
          <?if($pages){if(count($pages)>0){ $i=1; foreach($pages as $p){ $p = (object)$p;?>
            <tr>
            <td class="pt-3-half" contenteditable="true"><?=$i?></td>
            <td class="pt-3-half" contenteditable="true" id='page<?=$p->id?>'><?=$p->name?></td>
            <td class="pt-3-half">
              <span class="table-up"><a href="" class=" btn btn-primary indigo-text" data-toggle="modal" data-target="#modalLoginForm" id="editpage" data-id='<?=$p->id?>'><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a></span>
            </td>
            <td>
              <span class="table-remove"><a href="pager/<?=base64_encode($p->id)?>" type="button"
                  class="btn btn-danger btn-rounded btn-sm my-0">Remove</a></span>
            </td>
          </tr>
        <? $i++; }  }} ?>
          
        
        </tbody>
      </table>
    </div>
  </div>
</div>
<!-- Editable table -->
<script>
  $(document).ready(function(){
      $(document).on('click','#editpage',function(){   
        var id   = $(this).data('id');
        var name = $('#page'+id).text();
        $('#modal_id').val(id);
        $("#modal_name").val(name);
      })
    $("#modal_submit").click(function(){
      $('.close').trigger('click');
        var id = $("#modal_id").val();
        var name = $("#modal_name").val();
        $.ajax({
                type :"POST",
                url  :'<?=site_url('editpage')?>',
                data :"id="+id+'&name='+name,
                success:function(response){
if(response==1){
  alert(' Updated successfully');
  $("#page"+id).html(name);
}else 
  alert('Update Failed');
                }
        })
    });

  });
</script>
<!--end-->
      </div>

<!--end-->      
<? require_once('footer.php'); ?>
</body>

</html>
<!--modal form start-->
<div class="modal fade" id="modalLoginForm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
  aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header text-center">
        <h4 class="modal-title w-100 font-weight-bold">Update Page Name</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body mx-3">
       <input type="hidden" id="modal_id" class="form-control validate">
         

        <div class="md-form mb-4">
         <label data-error="wrong" data-success="right" for="defaultForm-pass">Enter Name</label>
          <input type="text" id="modal_name" class="form-control validate">
        </div><br>
        
          <div class="md-form mb-4">
          <input  type="button" id="modal_submit" class="btn btn-primary" value="udpate">
        </div>
      </div>
    <!--   <div class="modal-footer d-flex justify-content-center">
        <button class="btn btn-default">Login</button>
      </div> -->
    </div>
  </div>
</div>

<!-- <div class="text-center">
  <a href="" class="btn btn-default btn-rounded mb-4" data-toggle="modal" data-target="#modalLoginForm">Launch
    Modal Login Form</a>
</div> -->
<!--modal form end-->